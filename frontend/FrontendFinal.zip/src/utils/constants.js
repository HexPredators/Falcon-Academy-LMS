export const USER_ROLES = {
    SUPER_ADMIN: 'super_admin',
    DIRECTOR: 'director',
    TEACHER: 'teacher',
    STUDENT: 'student',
    PARENT: 'parent',
    ADMIN: 'admin',
    LIBRARIAN: 'librarian',
    OTHER: 'other'
  }
  
  export const GRADE_LEVELS = ['9', '10', '11', '12']
  
  export const SECTIONS = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
  
  export const STREAMS = {
    NATURAL_SCIENCE: 'Natural Science',
    SOCIAL_SCIENCE: 'Social Science'
  }
  
  export const SUBJECTS = [
    'Mathematics',
    'Physics',
    'Chemistry',
    'Biology',
    'English',
    'Amharic',
    'History',
    'Geography',
    'Civics',
    'ICT',
    'Physical Education',
    'Other'
  ]
  
  export const ASSIGNMENT_STATUS = {
    PENDING: 'pending',
    SUBMITTED: 'submitted',
    GRADED: 'graded',
    OVERDUE: 'overdue'
  }
  
  export const QUIZ_STATUS = {
    DRAFT: 'draft',
    PUBLISHED: 'published',
    ACTIVE: 'active',
    COMPLETED: 'completed'
  }
  
  export const NEWS_CATEGORIES = {
    PUBLIC: 'public',
    SCHOOL: 'school',
    GRADE: 'grade',
    SECTION: 'section'
  }
  
  export const BOOK_CATEGORIES = [
    'Textbook',
    'Reference',
    'Novel',
    'Research Paper',
    'Journal',
    'Guide',
    'Other'
  ]
  
  export const FILE_TYPES = {
    PDF: 'application/pdf',
    IMAGE: 'image/*',
    DOCUMENT: '.doc,.docx',
    SPREADSHEET: '.xls,.xlsx',
    PRESENTATION: '.ppt,.pptx'
  }
  
  export const NOTIFICATION_TYPES = {
    SUCCESS: 'success',
    ERROR: 'error',
    WARNING: 'warning',
    INFO: 'info'
  }
  
  export const LANGUAGES = {
    EN: { code: 'en', name: 'English', nativeName: 'English' },
    AM: { code: 'am', name: 'Amharic', nativeName: 'አማርኛ' },
    OM: { code: 'om', name: 'Afaan Oromoo', nativeName: 'Afaan Oromoo' },
    TI: { code: 'ti', name: 'Tigrigna', nativeName: 'ትግርኛ' }
  }
  
  export const THEMES = {
    LIGHT: 'light',
    DARK: 'dark',
    SYSTEM: 'system'
  }
  
  export const API_ENDPOINTS = {
    // Auth
    LOGIN: '/auth/login',
    REGISTER: '/auth/register',
    LOGOUT: '/auth/logout',
    VERIFY_OTP: '/auth/verify-otp',
    FORGOT_PASSWORD: '/auth/forgot-password',
    RESET_PASSWORD: '/auth/reset-password',
    
    // Users
    GET_USERS: '/users',
    GET_USER: '/users/:id',
    UPDATE_USER: '/users/:id',
    DELETE_USER: '/users/:id',
    
    // Students
    GET_STUDENTS: '/students',
    GET_STUDENT: '/students/:id',
    UPDATE_STUDENT: '/students/:id',
    GET_STUDENT_PROGRESS: '/students/:id/progress',
    
    // Teachers
    GET_TEACHERS: '/teachers',
    GET_TEACHER: '/teachers/:id',
    UPDATE_TEACHER: '/teachers/:id',
    
    // Assignments
    GET_ASSIGNMENTS: '/assignments',
    GET_ASSIGNMENT: '/assignments/:id',
    CREATE_ASSIGNMENT: '/assignments',
    UPDATE_ASSIGNMENT: '/assignments/:id',
    DELETE_ASSIGNMENT: '/assignments/:id',
    SUBMIT_ASSIGNMENT: '/assignments/:id/submit',
    GRADE_ASSIGNMENT: '/assignments/submissions/:id/grade',
    
    // Quizzes
    GET_QUIZZES: '/quizzes',
    GET_QUIZ: '/quizzes/:id',
    CREATE_QUIZ: '/quizzes',
    TAKE_QUIZ: '/quizzes/:id/take',
    GET_QUIZ_RESULTS: '/quizzes/:id/results',
    
    // Library
    GET_BOOKS: '/library',
    GET_BOOK: '/library/:id',
    UPLOAD_BOOK: '/library',
    UPDATE_PROGRESS: '/library/:id/progress',
    
    // News
    GET_NEWS: '/news',
    GET_NEWS_ITEM: '/news/:id',
    CREATE_NEWS: '/news',
    UPDATE_NEWS: '/news/:id',
    DELETE_NEWS: '/news/:id',
    
    // Messages
    GET_CONVERSATIONS: '/messages/conversations',
    GET_MESSAGES: '/messages/:id',
    SEND_MESSAGE: '/messages',
    
    // AI
    GET_LESSON_PLAN: '/ai/lesson-plan',
    GET_STUDY_PLAN: '/ai/study-plan',
    ASK_ASSISTANT: '/ai/assistant',
    
    // Analytics
    GET_DASHBOARD_STATS: '/analytics/dashboard',
    GET_GRADE_ANALYTICS: '/analytics/grade/:grade',
    GET_STUDENT_ANALYTICS: '/analytics/student/:id',
    GET_TEACHER_ANALYTICS: '/analytics/teacher/:id'
  }
  
  export const STORAGE_KEYS = {
    TOKEN: 'falcon_academy_token',
    USER: 'falcon_academy_user',
    LANGUAGE: 'falcon_academy_language',
    THEME: 'falcon_academy_theme',
    SETTINGS: 'falcon_academy_settings'
  }
export default constants.js