import axios from 'axios'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
})

api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export const authService = {
  login: (credentials) => api.post('/auth/login', credentials),
  register: (userData) => api.post('/auth/register', userData),
  logout: () => api.post('/auth/logout'),
  getProfile: () => api.get('/auth/profile'),
  updateProfile: (data) => api.put('/auth/profile', data)
}

export const userService = {
  getUsers: (params) => api.get('/users', { params }),
  getUser: (id) => api.get(`/users/${id}`),
  createUser: (data) => api.post('/users', data),
  updateUser: (id, data) => api.put(`/users/${id}`, data),
  deleteUser: (id) => api.delete(`/users/${id}`)
}

export const studentService = {
  getStudents: (params) => api.get('/students', { params }),
  getStudent: (id) => api.get(`/students/${id}`),
  updateStudent: (id, data) => api.put(`/students/${id}`, data),
  getStudentProgress: (id) => api.get(`/students/${id}/progress`)
}

export const teacherService = {
  getTeachers: (params) => api.get('/teachers', { params }),
  getTeacher: (id) => api.get(`/teachers/${id}`),
  createTeacher: (data) => api.post('/teachers', data)
}

export const assignmentService = {
  getAssignments: (params) => api.get('/assignments', { params }),
  getAssignment: (id) => api.get(`/assignments/${id}`),
  createAssignment: (data) => api.post('/assignments', data),
  updateAssignment: (id, data) => api.put(`/assignments/${id}`, data),
  deleteAssignment: (id) => api.delete(`/assignments/${id}`),
  submitAssignment: (id, data) => api.post(`/assignments/${id}/submit`, data),
  gradeAssignment: (submissionId, data) => api.put(`/assignments/submissions/${submissionId}/grade`, data)
}

export const quizService = {
  getQuizzes: (params) => api.get('/quizzes', { params }),
  getQuiz: (id) => api.get(`/quizzes/${id}`),
  createQuiz: (data) => api.post('/quizzes', data),
  takeQuiz: (id, data) => api.post(`/quizzes/${id}/take`, data),
  getQuizResults: (id) => api.get(`/quizzes/${id}/results`)
}

export const libraryService = {
  getBooks: (params) => api.get('/library', { params }),
  getBook: (id) => api.get(`/library/${id}`),
  uploadBook: (data) => api.post('/library', data),
  updateProgress: (bookId, data) => api.put(`/library/${bookId}/progress`, data)
}

export const newsService = {
  getNews: (params) => api.get('/news', { params }),
  getNewsItem: (id) => api.get(`/news/${id}`),
  createNews: (data) => api.post('/news', data),
  updateNews: (id, data) => api.put(`/news/${id}`, data),
  deleteNews: (id) => api.delete(`/news/${id}`)
}

export const messagingService = {
  getConversations: () => api.get('/messages/conversations'),
  getMessages: (conversationId) => api.get(`/messages/${conversationId}`),
  sendMessage: (data) => api.post('/messages', data)
}

export const aiService = {
  getLessonPlan: (data) => api.post('/ai/lesson-plan', data),
  getStudyPlan: (data) => api.post('/ai/study-plan', data),
  askAssistant: (data) => api.post('/ai/assistant', data)
}

export const analyticsService = {
  getDashboardStats: () => api.get('/analytics/dashboard'),
  getGradeAnalytics: (grade) => api.get(`/analytics/grade/${grade}`),
  getStudentAnalytics: (studentId) => api.get(`/analytics/student/${studentId}`),
  getTeacherAnalytics: (teacherId) => api.get(`/analytics/teacher/${teacherId}`)
}

export default api