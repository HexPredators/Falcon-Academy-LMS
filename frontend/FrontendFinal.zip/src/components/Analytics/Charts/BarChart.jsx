import React from 'react'
import {
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell
} from 'recharts'

const CustomBarChart = ({
  data,
  bars,
  height = 300,
  showGrid = true,
  showLegend = true,
  showTooltip = true,
  xAxisKey = 'name',
  barRadius = [4, 4, 0, 0],
  stacked = false,
  customTooltip
}) => {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <RechartsBarChart data={data}>
        {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#374151" />}
        <XAxis 
          dataKey={xAxisKey} 
          stroke="#9CA3AF"
          tick={{ fill: '#6B7280' }}
        />
        <YAxis 
          stroke="#9CA3AF"
          tick={{ fill: '#6B7280' }}
        />
        
        {showTooltip && (
          customTooltip ? (
            <Tooltip content={customTooltip} />
          ) : (
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1F2937',
                border: 'none',
                borderRadius: '0.5rem',
                color: '#F9FAFB'
              }}
              labelStyle={{ color: '#9CA3AF' }}
            />
          )
        )}
        
        {showLegend && <Legend />}
        
        {bars.map((bar, index) => (
          <Bar
            key={bar.dataKey}
            dataKey={bar.dataKey}
            name={bar.name}
            fill={bar.color}
            radius={barRadius}
            stackId={stacked ? 'stack' : undefined}
          >
            {bar.customColors && data.map((entry, i) => (
              <Cell key={`cell-${i}`} fill={bar.customColors[i % bar.customColors.length]} />
            ))}
          </Bar>
        ))}
      </RechartsBarChart>
    </ResponsiveContainer>
  )
}

export default CustomBarChart