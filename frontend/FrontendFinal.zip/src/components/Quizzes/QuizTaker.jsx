// frontend/src/components/Quizzes/QuizTaker.jsx
import React, { useState, useEffect, useRef } from 'react';
import { useMutation } from 'react-query';
import { 
  Clock, 
  CheckCircle, 
  AlertTriangle, 
  Maximize2,
  Minimize2,
  Eye,
  EyeOff
} from 'lucide-react';
import { useSocket } from '../../contexts/SocketContext';
import { useNotification } from '../../contexts/NotificationContext';
import { quizService } from '../../services/quizService';

const QuizTaker = ({ quiz, onComplete, onExit }) => {
  const { emitEvent, isConnected } = useSocket();
  const { showNotification } = useNotification();

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [timeLeft, setTimeLeft] = useState(quiz.timeLimit * 60); // Convert to seconds
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [violationCount, setViolationCount] = useState(0);
  const [showWarning, setShowWarning] = useState(false);

  const quizContainerRef = useRef();
  const startTimeRef = useRef(Date.now());

  // Timer effect
  useEffect(() => {
    if (timeLeft <= 0) {
      handleAutoSubmit();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          handleAutoSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  // Security monitoring effects
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        handleSecurityViolation('tab_switch', 'User switched tabs during quiz');
      }
    };

    const handleFullscreenChange = () => {
      const isNowFullscreen = document.fullscreenElement !== null;
      if (!isNowFullscreen && isFullscreen) {
        handleSecurityViolation('fullscreen_exit', 'User exited fullscreen mode');
      }
      setIsFullscreen(isNowFullscreen);
    };

    const handleKeyDown = (event) => {
      if (event.ctrlKey || event.metaKey) {
        if (event.key === 'c' || event.key === 'v') {
          handleSecurityViolation('keyboard_shortcut', `Blocked keyboard shortcut: ${event.key}`);
          event.preventDefault();
        }
      }

      if (event.key === 'F12') {
        handleSecurityViolation('dev_tools', 'Attempted to open developer tools');
        event.preventDefault();
      }
    };

    const handleContextMenu = (event) => {
      handleSecurityViolation('right_click', 'Right-click disabled during quiz');
      event.preventDefault();
    };

    // Add event listeners
    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('contextmenu', handleContextMenu);

    // Request fullscreen on start
    requestFullscreen();

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('contextmenu', handleContextMenu);
      
      // Exit fullscreen on unmount
      if (document.fullscreenElement) {
        document.exitFullscreen();
      }
    };
  }, [isFullscreen]);

  const requestFullscreen = async () => {
    try {
      if (quizContainerRef.current) {
        await quizContainerRef.current.requestFullscreen();
        setIsFullscreen(true);
      }
    } catch (error) {
      console.warn('Fullscreen not supported:', error);
    }
  };

  const handleSecurityViolation = (type, details) => {
    setViolationCount(prev => {
      const newCount = prev + 1;
      
      // Report to server
      emitEvent('security_violation', {
        attempt_id: quiz.attemptId,
        violation_type: type,
        details: details
      });

      // Show warning to user
      if (newCount >= 3) {
        setShowWarning(true);
        setTimeout(() => setShowWarning(false), 5000);
      }

      // Auto-submit after too many violations
      if (newCount >= 5) {
        handleAutoSubmit();
        showNotification({
          type: 'error',
          title: 'Quiz Terminated',
          message: 'Too many security violations detected'
        });
      }

      return newCount;
    });
  };

  const handleAnswer = (questionIndex, answer) => {
    setAnswers(prev => ({
      ...prev,
      [questionIndex]: answer
    }));
  };

  const handleNext = () => {
    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    try {
      await quizService.submitQuiz(quiz.attemptId, {
        answers: Object.values(answers)
      });
      
      onComplete();
      showNotification({
        type: 'success',
        title: 'Quiz Submitted',
        message: 'Your quiz has been submitted successfully'
      });
    } catch (error) {
      showNotification({
        type: 'error',
        title: 'Submission Failed',
        message: error.message || 'Failed to submit quiz'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAutoSubmit = () => {
    if (!isSubmitting) {
      showNotification({
        type: 'warning',
        title: 'Time Up!',
        message: 'Quiz automatically submitted due to time limit'
      });
      handleSubmit();
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const currentQ = quiz.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / quiz.questions.length) * 100;
  const answeredCount = Object.keys(answers).length;

  if (!isConnected) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Connection Lost</h1>
          <p className="text-gray-600 mb-4">
            Please check your internet connection and try again.
          </p>
          <button
            onClick={onExit}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Exit Quiz
          </button>
        </div>
      </div>
    );
  }

  return (
    <div ref={quizContainerRef} className="min-h-screen bg-gray-900 text-white">
      {/* Security Warning */}
      {showWarning && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50">
          <div className="bg-red-600 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5" />
            <span>Security violation detected! Further violations may result in quiz termination.</span>
          </div>
        </div>
      )}

      {/* Quiz Header */}
      <div className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={onExit}
                className="text-gray-400 hover:text-white transition-colors"
              >
                ← Exit
              </button>
              <h1 className="text-xl font-bold">{quiz.title}</h1>
            </div>

            <div className="flex items-center space-x-6">
              {/* Time Display */}
              <div className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${
                timeLeft < 300 ? 'bg-red-600' : 'bg-gray-700'
              }`}>
                <Clock className="h-5 w-5" />
                <span className="font-mono font-bold">{formatTime(timeLeft)}</span>
              </div>

              {/* Progress */}
              <div className="hidden md:block">
                <span className="text-sm text-gray-400">
                  {currentQuestion + 1} of {quiz.questions.length}
                </span>
              </div>

              {/* Fullscreen Toggle */}
              <button
                onClick={isFullscreen ? () => document.exitFullscreen() : requestFullscreen}
                className="text-gray-400 hover:text-white transition-colors"
              >
                {isFullscreen ? <Minimize2 className="h-5 w-5" /> : <Maximize2 className="h-5 w-5" />}
              </button>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mt-4 w-full bg-gray-700 rounded-full h-2">
            <div 
              className="bg-blue-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Quiz Content */}
      <div className="max-w-4xl mx-auto p-6">
        {/* Question Navigation */}
        <div className="flex flex-wrap gap-2 mb-6">
          {quiz.questions.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentQuestion(index)}
              className={`w-8 h-8 rounded text-sm font-medium ${
                currentQuestion === index
                  ? 'bg-blue-600 text-white'
                  : answers[index] !== undefined
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              {index + 1}
            </button>
          ))}
        </div>

        {/* Current Question */}
        <div className="bg-gray-800 rounded-lg p-6 mb-6">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-xl font-semibold">
              Question {currentQuestion + 1}
            </h2>
            <span className="text-sm text-gray-400 bg-gray-700 px-2 py-1 rounded">
              {currentQ.points || 1} point{currentQ.points !== 1 ? 's' : ''}
            </span>
          </div>

          <p className="text-lg mb-6">{currentQ.question}</p>

          {/* Answer Options */}
          <div className="space-y-3">
            {currentQ.type === 'multiple_choice' && currentQ.options.map((option, index) => (
              <label key={index} className="flex items-center space-x-3 p-3 border border-gray-600 rounded-lg hover:bg-gray-700 cursor-pointer transition-colors">
                <input
                  type="radio"
                  name={`question-${currentQuestion}`}
                  value={index}
                  checked={answers[currentQuestion] === index}
                  onChange={() => handleAnswer(currentQuestion, index)}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <span>{option}</span>
              </label>
            ))}

            {currentQ.type === 'true_false' && (
              <div className="space-y-3">
                {[true, false].map((value) => (
                  <label key={value} className="flex items-center space-x-3 p-3 border border-gray-600 rounded-lg hover:bg-gray-700 cursor-pointer transition-colors">
                    <input
                      type="radio"
                      name={`question-${currentQuestion}`}
                      value={value}
                      checked={answers[currentQuestion] === value}
                      onChange={() => handleAnswer(currentQuestion, value)}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span>{value ? 'True' : 'False'}</span>
                  </label>
                ))}
              </div>
            )}

            {currentQ.type === 'short_answer' && (
              <textarea
                value={answers[currentQuestion] || ''}
                onChange={(e) => handleAnswer(currentQuestion, e.target.value)}
                placeholder="Type your answer here..."
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white"
                rows="3"
              />
            )}

            {currentQ.type === 'essay' && (
              <div>
                <textarea
                  value={answers[currentQuestion] || ''}
                  onChange={(e) => handleAnswer(currentQuestion, e.target.value)}
                  placeholder="Write your essay answer here..."
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white"
                  rows="6"
                />
                <p className="text-sm text-gray-400 mt-2">
                  This question requires manual grading by your teacher.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between items-center">
          <button
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            className="px-6 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Previous
          </button>

          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-400">
              {answeredCount} of {quiz.questions.length} answered
            </span>

            {currentQuestion === quiz.questions.length - 1 ? (
              <button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 flex items-center space-x-2 transition-colors"
              >
                <CheckCircle className="h-5 w-5" />
                <span>{isSubmitting ? 'Submitting...' : 'Submit Quiz'}</span>
              </button>
            ) : (
              <button
                onClick={handleNext}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Next Question
              </button>
            )}
          </div>
        </div>

        {/* Security Warning Footer */}
        {violationCount > 0 && (
          <div className="mt-6 p-4 bg-yellow-600 bg-opacity-20 border border-yellow-500 rounded-lg">
            <div className="flex items-center space-x-2 text-yellow-400">
              <EyeOff className="h-5 w-5" />
              <span className="text-sm">
                Security monitoring active. Violations detected: {violationCount}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuizTaker;