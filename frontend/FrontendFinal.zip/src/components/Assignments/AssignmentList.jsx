import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Search, 
  Filter, 
  Calendar, 
  Clock, 
  FileText,
  Upload,
  CheckCircle,
  AlertCircle
} from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import { useLanguage } from '../../contexts/LanguageContext'
import AssignmentCard from './AssignmentCard'
import CreateAssignment from './CreateAssignment'

const AssignmentList = () => {
  const [assignments, setAssignments] = useState([])
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')
  const [showCreate, setShowCreate] = useState(false)
  const { user } = useAuth()
  const { t } = useLanguage()

  const mockAssignments = [
    {
      id: 1,
      title: 'Mathematics - Calculus Basics',
      subject: 'Mathematics',
      grade: '11',
      section: 'A',
      dueDate: '2024-01-15',
      status: 'pending',
      points: 100,
      submitted: false
    },
    {
      id: 2,
      title: 'Physics - Newton Laws',
      subject: 'Physics',
      grade: '11',
      section: 'A',
      dueDate: '2024-01-10',
      status: 'graded',
      points: 95,
      submitted: true
    },
    {
      id: 3,
      title: 'Chemistry - Organic Compounds',
      subject: 'Chemistry',
      grade: '11',
      section: 'B',
      dueDate: '2024-01-20',
      status: 'pending',
      points: 100,
      submitted: false
    }
  ]

  useEffect(() => {
    setAssignments(mockAssignments)
  }, [])

  const filteredAssignments = assignments.filter(assignment => {
    const matchesSearch = assignment.title.toLowerCase().includes(search.toLowerCase()) ||
                         assignment.subject.toLowerCase().includes(search.toLowerCase())
    
    if (filter === 'all') return matchesSearch
    if (filter === 'pending') return matchesSearch && assignment.status === 'pending'
    if (filter === 'graded') return matchesSearch && assignment.status === 'graded'
    if (filter === 'submitted') return matchesSearch && assignment.submitted
    return matchesSearch
  })

  const stats = {
    total: assignments.length,
    pending: assignments.filter(a => a.status === 'pending').length,
    graded: assignments.filter(a => a.status === 'graded').length,
    submitted: assignments.filter(a => a.submitted).length
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">{t('assignments')}</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Manage and track all your assignments
          </p>
        </div>

        {user?.role === 'teacher' && (
          <button
            onClick={() => setShowCreate(true)}
            className="btn-primary flex items-center gap-2"
          >
            <FileText className="h-4 w-4" />
            Create Assignment
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="card p-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Total</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </div>
            <FileText className="h-8 w-8 text-blue-600" />
          </div>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.02 }}
          className="card p-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Pending</p>
              <p className="text-2xl font-bold">{stats.pending}</p>
            </div>
            <Clock className="h-8 w-8 text-yellow-600" />
          </div>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.02 }}
          className="card p-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Graded</p>
              <p className="text-2xl font-bold">{stats.graded}</p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.02 }}
          className="card p-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Submitted</p>
              <p className="text-2xl font-bold">{stats.submitted}</p>
            </div>
            <Upload className="h-8 w-8 text-purple-600" />
          </div>
        </motion.div>
      </div>

      <div className="card p-4">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search assignments..."
              className="input-field pl-10"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-gray-400" />
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="input-field"
            >
              <option value="all">All Assignments</option>
              <option value="pending">Pending</option>
              <option value="graded">Graded</option>
              <option value="submitted">Submitted</option>
            </select>
          </div>
        </div>

        <div className="space-y-4">
          {filteredAssignments.length > 0 ? (
            filteredAssignments.map((assignment, index) => (
              <motion.div
                key={assignment.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <AssignmentCard assignment={assignment} />
              </motion.div>
            ))
          ) : (
            <div className="text-center py-12">
              <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No assignments found</h3>
              <p className="text-gray-500 dark:text-gray-400">
                {search ? 'Try a different search term' : 'No assignments available yet'}
              </p>
            </div>
          )}
        </div>
      </div>

      {showCreate && (
        <CreateAssignment onClose={() => setShowCreate(false)} />
      )}
    </div>
  )
}

export default AssignmentList