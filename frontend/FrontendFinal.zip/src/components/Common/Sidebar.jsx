import React from 'react'
import { NavLink } from 'react-router-dom'
import { motion } from 'framer-motion'
import { 
  Home, 
  BookOpen, 
  FileText, 
  MessageSquare, 
  Bell, 
  BarChart3,
  Settings,
  User,
  LogOut
} from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import { useLanguage } from '../../contexts/LanguageContext'

const Sidebar = () => {
  const { user, logout } = useAuth()
  const { t } = useLanguage()

  const navItems = [
    { path: '/dashboard', icon: Home, label: t('dashboard') },
    { path: '/assignments', icon: FileText, label: t('assignments') },
    { path: '/quizzes', icon: BookOpen, label: t('quizzes') },
    { path: '/library', icon: BookOpen, label: t('library') },
    { path: '/messages', icon: MessageSquare, label: t('messages') },
    { path: '/news', icon: Bell, label: t('news') },
    { path: '/analytics', icon: BarChart3, label: t('analytics') },
  ]

  return (
    <motion.aside
      initial={{ x: -300 }}
      animate={{ x: 0 }}
      className="fixed left-0 top-0 h-screen w-64 border-r bg-white dark:bg-gray-900 z-40"
    >
      <div className="flex h-full flex-col">
        <div className="p-6 border-b">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
              <BookOpen className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold">Falcon Academy</h2>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {user?.role === 'student' && 'Student Portal'}
                {user?.role === 'teacher' && 'Teacher Portal'}
                {user?.role === 'parent' && 'Parent Portal'}
                {user?.role === 'director' && 'Director Portal'}
                {user?.role === 'admin' && 'Admin Portal'}
              </p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          <nav className="space-y-1">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) => `
                  flex items-center gap-3 px-4 py-3 rounded-lg transition-colors
                  ${isActive 
                    ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400' 
                    : 'hover:bg-gray-50 dark:hover:bg-gray-800'
                  }
                `}
              >
                <item.icon className="h-5 w-5" />
                <span className="font-medium">{item.label}</span>
              </NavLink>
            ))}
          </nav>
        </div>

        <div className="border-t p-4">
          <div className="mb-4">
            <NavLink
              to="/profile"
              className={({ isActive }) => `
                flex items-center gap-3 px-4 py-3 rounded-lg transition-colors
                ${isActive 
                  ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400' 
                  : 'hover:bg-gray-50 dark:hover:bg-gray-800'
                }
              `}
            >
              <User className="h-5 w-5" />
              <span className="font-medium">{t('profile')}</span>
            </NavLink>
            <NavLink
              to="/settings"
              className={({ isActive }) => `
                flex items-center gap-3 px-4 py-3 rounded-lg transition-colors
                ${isActive 
                  ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400' 
                  : 'hover:bg-gray-50 dark:hover:bg-gray-800'
                }
              `}
            >
              <Settings className="h-5 w-5" />
              <span className="font-medium">{t('settings')}</span>
            </NavLink>
          </div>
          <button
            onClick={logout}
            className="flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 w-full transition-colors"
          >
            <LogOut className="h-5 w-5" />
            <span className="font-medium">{t('logout')}</span>
          </button>
        </div>
      </div>
    </motion.aside>
  )
}

export default Sidebar 