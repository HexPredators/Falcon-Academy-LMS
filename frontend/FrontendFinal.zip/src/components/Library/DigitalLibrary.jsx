import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Search, 
  Filter, 
  BookOpen, 
  Download,
  Eye,
  Star,
  Clock,
  Upload
} from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import { useLanguage } from '../../contexts/LanguageContext'
import BookCard from './BookCard'
import UploadBook from './UploadBook'

const DigitalLibrary = () => {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('all')
  const [grade, setGrade] = useState('all')
  const [showUpload, setShowUpload] = useState(false)
  const { user } = useAuth()
  const { t } = useLanguage()

  const books = [
    {
      id: 1,
      title: 'Mathematics Grade 11',
      author: 'Ethiopian Ministry of Education',
      subject: 'Mathematics',
      grade: '11',
      pages: 350,
      rating: 4.8,
      reads: 1245,
      coverColor: 'bg-blue-500'
    },
    {
      id: 2,
      title: 'Physics for Natural Science',
      author: 'Dr. Alemayehu Bekele',
      subject: 'Physics',
      grade: '12',
      pages: 420,
      rating: 4.6,
      reads: 987,
      coverColor: 'bg-purple-500'
    },
    {
      id: 3,
      title: 'Chemistry Laboratory Manual',
      author: 'Prof. Samuel Getachew',
      subject: 'Chemistry',
      grade: '11',
      pages: 280,
      rating: 4.9,
      reads: 1567,
      coverColor: 'bg-green-500'
    },
    {
      id: 4,
      title: 'Ethiopian History',
      author: 'Dr. Mesfin Woldemariam',
      subject: 'History',
      grade: '10',
      pages: 320,
      rating: 4.7,
      reads: 876,
      coverColor: 'bg-orange-500'
    },
    {
      id: 5,
      title: 'English Literature',
      author: 'Mrs. Sarah Johnson',
      subject: 'English',
      grade: '9',
      pages: 290,
      rating: 4.5,
      reads: 654,
      coverColor: 'bg-red-500'
    },
    {
      id: 6,
      title: 'Biology Textbook',
      author: 'Dr. Helen Mekonnen',
      subject: 'Biology',
      grade: '12',
      pages: 380,
      rating: 4.8,
      reads: 1123,
      coverColor: 'bg-teal-500'
    }
  ]

  const categories = ['all', 'Mathematics', 'Physics', 'Chemistry', 'Biology', 'History', 'English']
  const grades = ['all', '9', '10', '11', '12']

  const filteredBooks = books.filter(book => {
    const matchesSearch = book.title.toLowerCase().includes(search.toLowerCase()) ||
                         book.author.toLowerCase().includes(search.toLowerCase())
    const matchesCategory = category === 'all' || book.subject === category
    const matchesGrade = grade === 'all' || book.grade === grade
    return matchesSearch && matchesCategory && matchesGrade
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">{t('library')}</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Access thousands of educational resources
          </p>
        </div>

        {(user?.role === 'teacher' || user?.role === 'admin') && (
          <button
            onClick={() => setShowUpload(true)}
            className="btn-primary flex items-center gap-2"
          >
            <Upload className="h-4 w-4" />
            Upload Resource
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="card p-6 col-span-1 md:col-span-2"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Total Books</p>
              <p className="text-3xl font-bold">{books.length}</p>
            </div>
            <BookOpen className="h-12 w-12 text-blue-600" />
          </div>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.02 }}
          className="card p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Total Reads</p>
              <p className="text-2xl font-bold">
                {books.reduce((sum, book) => sum + book.reads, 0).toLocaleString()}
              </p>
            </div>
            <Eye className="h-8 w-8 text-green-600" />
          </div>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.02 }}
          className="card p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Avg Rating</p>
              <p className="text-2xl font-bold">
                {(books.reduce((sum, book) => sum + book.rating, 0) / books.length).toFixed(1)}
              </p>
            </div>
            <Star className="h-8 w-8 text-yellow-600" />
          </div>
        </motion.div>
      </div>

      <div className="card p-4">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search books, authors, or subjects..."
              className="input-field pl-10"
            />
          </div>

          <div className="flex gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-5 w-5 text-gray-400" />
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="input-field"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>
                    {cat === 'all' ? 'All Subjects' : cat}
                  </option>
                ))}
              </select>
            </div>

            <select
              value={grade}
              onChange={(e) => setGrade(e.target.value)}
              className="input-field"
            >
              {grades.map(g => (
                <option key={g} value={g}>
                  {g === 'all' ? 'All Grades' : `Grade ${g}`}
                </option>
              ))}
            </select>
          </div>
        </div>

        {filteredBooks.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBooks.map((book, index) => (
              <motion.div
                key={book.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <BookCard book={book} />
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No books found</h3>
            <p className="text-gray-500 dark:text-gray-400">
              Try adjusting your search or filters
            </p>
          </div>
        )}
      </div>

      {showUpload && (
        <UploadBook onClose={() => setShowUpload(false)} />
      )}
    </div>
  )
}

export default DigitalLibrary