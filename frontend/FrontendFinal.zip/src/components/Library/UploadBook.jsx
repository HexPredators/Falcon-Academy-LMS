import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  X, 
  Upload, 
  BookOpen,
  FileText,
  Plus,
  Trash2,
  Image
} from 'lucide-react'
import { useLanguage } from '../../contexts/LanguageContext'

const UploadBook = ({ onClose }) => {
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    subject: '',
    grade: '',
    description: '',
    isbn: '',
    pages: '',
    coverImage: null,
    file: null,
    categories: [],
    tags: []
  })
  const [isUploading, setIsUploading] = useState(false)
  const { t } = useLanguage()

  const subjects = [
    'Mathematics', 'Physics', 'Chemistry', 'Biology',
    'English', 'Amharic', 'History', 'Geography',
    'Civics', 'ICT', 'Physical Education', 'Other'
  ]

  const grades = ['All', '9', '10', '11', '12']
  const categories = ['Textbook', 'Reference', 'Novel', 'Research', 'Journal', 'Guide']
  const tags = ['Ethiopian Curriculum', 'Exam Preparation', 'Digital Edition', 'Interactive', 'Free Access']

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleCategoryToggle = (category) => {
    setFormData(prev => ({
      ...prev,
      categories: prev.categories.includes(category)
        ? prev.categories.filter(c => c !== category)
        : [...prev.categories, category]
    }))
  }

  const handleTagToggle = (tag) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.includes(tag)
        ? prev.tags.filter(t => t !== tag)
        : [...prev.tags, tag]
    }))
  }

  const handleFileUpload = (e, type) => {
    const file = e.target.files[0]
    if (file) {
      if (type === 'cover') {
        if (!file.type.startsWith('image/')) {
          alert('Please upload an image file for cover')
          return
        }
        if (file.size > 5 * 1024 * 1024) {
          alert('Cover image must be less than 5MB')
          return
        }
        setFormData(prev => ({ ...prev, coverImage: file }))
      } else {
        if (file.type !== 'application/pdf') {
          alert('Please upload a PDF file')
          return
        }
        if (file.size > 50 * 1024 * 1024) {
          alert('File must be less than 50MB')
          return
        }
        setFormData(prev => ({ ...prev, file }))
      }
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!formData.file) {
      alert('Please upload a PDF file')
      return
    }

    setIsUploading(true)
    
    setTimeout(() => {
      console.log('Book uploaded:', formData)
      setIsUploading(false)
      onClose()
    }, 2000)
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-4xl max-h-[90vh] overflow-y-auto"
      >
        <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl">
          <div className="p-6 border-b dark:border-gray-800">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-semibold">Upload New Resource</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Add educational materials to the digital library
                </p>
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Title *
                </label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  className="input-field"
                  placeholder="e.g., Mathematics Grade 11 Textbook"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Author *
                </label>
                <input
                  type="text"
                  name="author"
                  value={formData.author}
                  onChange={handleInputChange}
                  className="input-field"
                  placeholder="e.g., Ethiopian Ministry of Education"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Subject *
                </label>
                <select
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  className="input-field"
                  required
                >
                  <option value="">Select Subject</option>
                  {subjects.map(subject => (
                    <option key={subject} value={subject}>{subject}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Grade Level
                </label>
                <select
                  name="grade"
                  value={formData.grade}
                  onChange={handleInputChange}
                  className="input-field"
                >
                  <option value="">Select Grade</option>
                  {grades.map(grade => (
                    <option key={grade} value={grade}>
                      {grade === 'All' ? 'All Grades' : `Grade ${grade}`}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Description
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                rows="3"
                className="input-field"
                placeholder="Provide a detailed description of the resource..."
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">
                  ISBN (Optional)
                </label>
                <input
                  type="text"
                  name="isbn"
                  value={formData.isbn}
                  onChange={handleInputChange}
                  className="input-field"
                  placeholder="e.g., 978-3-16-148410-0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Number of Pages
                </label>
                <input
                  type="number"
                  name="pages"
                  value={formData.pages}
                  onChange={handleInputChange}
                  className="input-field"
                  placeholder="e.g., 350"
                  min="1"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Categories
              </label>
              <div className="flex flex-wrap gap-2">
                {categories.map(category => (
                  <button
                    key={category}
                    type="button"
                    onClick={() => handleCategoryToggle(category)}
                    className={`px-3 py-2 rounded-lg border text-sm ${
                      formData.categories.includes(category)
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                        : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Tags
              </label>
              <div className="flex flex-wrap gap-2">
                {tags.map(tag => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => handleTagToggle(tag)}
                    className={`px-3 py-2 rounded-lg border text-sm ${
                      formData.tags.includes(tag)
                        ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400'
                        : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Cover Image
                </label>
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-6 text-center">
                  <input
                    type="file"
                    id="cover-upload"
                    className="hidden"
                    accept="image/*"
                    onChange={(e) => handleFileUpload(e, 'cover')}
                  />
                  <label
                    htmlFor="cover-upload"
                    className="cursor-pointer flex flex-col items-center"
                  >
                    {formData.coverImage ? (
                      <>
                        <Image className="h-12 w-12 text-green-600 mb-4" />
                        <p className="font-medium mb-1">{formData.coverImage.name}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Click to change
                        </p>
                      </>
                    ) : (
                      <>
                        <Image className="h-12 w-12 text-gray-400 mb-4" />
                        <p className="font-medium mb-1">Upload Cover Image</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Click to upload
                        </p>
                      </>
                    )}
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  PDF File *
                </label>
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-6 text-center">
                  <input
                    type="file"
                    id="file-upload"
                    className="hidden"
                    accept=".pdf"
                    onChange={(e) => handleFileUpload(e, 'file')}
                  />
                  <label
                    htmlFor="file-upload"
                    className="cursor-pointer flex flex-col items-center"
                  >
                    {formData.file ? (
                      <>
                        <FileText className="h-12 w-12 text-green-600 mb-4" />
                        <p className="font-medium mb-1">{formData.file.name}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {(formData.file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </>
                    ) : (
                      <>
                        <Upload className="h-12 w-12 text-gray-400 mb-4" />
                        <p className="font-medium mb-1">Upload PDF File</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Click to upload • Max 50MB
                        </p>
                      </>
                    )}
                  </label>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-6 border-t dark:border-gray-800">
              <button
                type="button"
                onClick={onClose}
                className="btn-secondary"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isUploading}
                className="btn-primary flex items-center gap-2"
              >
                {isUploading ? (
                  <>
                    <BookOpen className="h-4 w-4 animate-pulse" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Plus className="h-4 w-4" />
                    Upload Resource
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  )
}

export default UploadBook