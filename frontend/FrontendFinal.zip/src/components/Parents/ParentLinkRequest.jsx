import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  UserPlus, 
  Search,
  X,
  Check,
  Clock,
  AlertCircle
} from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'

const ParentLinkRequest = () => {
  const [searchData, setSearchData] = useState({
    studentName: '',
    favId: '',
    grade: '',
    section: ''
  })
  const [searchResults, setSearchResults] = useState([])
  const [isSearching, setIsSearching] = useState(false)
  const [pendingRequests, setPendingRequests] = useState([
    {
      id: 1,
      studentName: 'Samuel Getachew',
      grade: '11',
      section: 'A',
      favId: 'FAV202311045',
      requestedAt: '2024-01-10',
      status: 'pending'
    }
  ])
  const { user } = useAuth()

  const handleSearchChange = (e) => {
    const { name, value } = e.target
    setSearchData(prev => ({ ...prev, [name]: value }))
  }

  const handleSearch = (e) => {
    e.preventDefault()
    if (!searchData.studentName && !searchData.favId) {
      alert('Please enter at least student name or FAV/ID')
      return
    }

    setIsSearching(true)
    
    setTimeout(() => {
      const mockResults = [
        {
          id: 1,
          name: 'Samuel Getachew',
          grade: '11',
          section: 'A',
          favId: 'FAV202311045',
          stream: 'Natural Science',
          birthDate: '2006-05-15'
        },
        {
          id: 2,
          name: 'Meron Getachew',
          grade: '9',
          section: 'B',
          favId: 'FAV202309123',
          stream: null,
          birthDate: '2008-08-22'
        }
      ].filter(student => 
        student.name.toLowerCase().includes(searchData.studentName.toLowerCase()) ||
        student.favId.includes(searchData.favId)
      )
      
      setSearchResults(mockResults)
      setIsSearching(false)
    }, 1000)
  }

  const sendLinkRequest = (studentId) => {
    const student = searchResults.find(s => s.id === studentId)
    if (student) {
      const newRequest = {
        id: Date.now(),
        studentName: student.name,
        grade: student.grade,
        section: student.section,
        favId: student.favId,
        requestedAt: new Date().toISOString().split('T')[0],
        status: 'pending'
      }
      
      setPendingRequests(prev => [...prev, newRequest])
      setSearchResults([])
      alert(`Link request sent to ${student.name}. Waiting for student approval.`)
    }
  }

  const cancelRequest = (requestId) => {
    setPendingRequests(prev => prev.filter(req => req.id !== requestId))
  }

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-lg font-semibold mb-2">Link Child Account</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Send a link request to connect with your child's account
        </p>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="card p-6"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
            <UserPlus className="h-5 w-5 text-white" />
          </div>
          <div>
            <h4 className="font-semibold">Find Your Child</h4>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Search for your child using their details
            </p>
          </div>
        </div>

        <form onSubmit={handleSearch} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Student's Full Name
              </label>
              <input
                type="text"
                name="studentName"
                value={searchData.studentName}
                onChange={handleSearchChange}
                className="input-field"
                placeholder="e.g., Samuel Getachew"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                FAV/ID Number
              </label>
              <input
                type="text"
                name="favId"
                value={searchData.favId}
                onChange={handleSearchChange}
                className="input-field"
                placeholder="e.g., FAV202311045"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Grade
              </label>
              <select
                name="grade"
                value={searchData.grade}
                onChange={handleSearchChange}
                className="input-field"
              >
                <option value="">Select Grade</option>
                <option value="9">Grade 9</option>
                <option value="10">Grade 10</option>
                <option value="11">Grade 11</option>
                <option value="12">Grade 12</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Section
              </label>
              <select
                name="section"
                value={searchData.section}
                onChange={handleSearchChange}
                className="input-field"
              >
                <option value="">Select Section</option>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
                <option value="E">E</option>
                <option value="F">F</option>
                <option value="G">G</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isSearching}
              className="btn-primary flex items-center gap-2"
            >
              {isSearching ? (
                <>
                  <Search className="h-4 w-4 animate-spin" />
                  Searching...
                </>
              ) : (
                <>
                  <Search className="h-4 w-4" />
                  Search Student
                </>
              )}
            </button>
          </div>
        </form>
      </motion.div>

      {searchResults.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="card p-6"
        >
          <h4 className="font-semibold mb-4">Search Results</h4>
          <div className="space-y-4">
            {searchResults.map(student => (
              <div
                key={student.id}
                className="flex items-center justify-between p-4 rounded-lg border"
              >
                <div>
                  <h5 className="font-medium">{student.name}</h5>
                  <div className="flex items-center gap-3 text-sm text-gray-500 dark:text-gray-400 mt-1">
                    <span>Grade {student.grade}</span>
                    <span>•</span>
                    <span>Section {student.section}</span>
                    <span>•</span>
                    <span>FAV/ID: {student.favId}</span>
                    {student.stream && (
                      <>
                        <span>•</span>
                        <span>{student.stream}</span>
                      </>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => sendLinkRequest(student.id)}
                  className="btn-primary flex items-center gap-2"
                >
                  <UserPlus className="h-4 w-4" />
                  Send Link Request
                </button>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="card p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h4 className="font-semibold">Pending Link Requests</h4>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Requests waiting for student approval
            </p>
          </div>
          <span className="px-3 py-1 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300 rounded-full text-sm font-medium">
            {pendingRequests.length} pending
          </span>
        </div>

        {pendingRequests.length > 0 ? (
          <div className="space-y-4">
            {pendingRequests.map(request => (
              <div
                key={request.id}
                className="flex items-center justify-between p-4 rounded-lg border border-yellow-200 dark:border-yellow-800 bg-yellow-50 dark:bg-yellow-900/20"
              >
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-full bg-gradient-to-br from-yellow-500 to-orange-600 flex items-center justify-center">
                    <Clock className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h5 className="font-medium">{request.studentName}</h5>
                    <div className="flex items-center gap-3 text-sm text-gray-600 dark:text-gray-400 mt-1">
                      <span>Grade {request.grade}</span>
                      <span>•</span>
                      <span>Section {request.section}</span>
                      <span>•</span>
                      <span>Requested: {request.requestedAt}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="px-3 py-1 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300 rounded-full text-xs font-medium">
                    {request.status}
                  </span>
                  <button
                    onClick={() => cancelRequest(request.id)}
                    className="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
                  >
                    <X className="h-4 w-4 text-red-600" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 dark:text-gray-400">
              No pending link requests
            </p>
          </div>
        )}
      </motion.div>
    </div>
  )
}

export default ParentLinkRequest