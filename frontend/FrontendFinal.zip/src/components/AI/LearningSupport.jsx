import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Brain, 
  Lightbulb, 
  BookOpen,
  Target,
  RefreshCw,
  Download,
  PlayCircle,
  PauseCircle
} from 'lucide-react'
import { useLanguage } from '../../contexts/LanguageContext'

const LearningSupport = () => {
  const [activeTab, setActiveTab] = useState('concepts')
  const [selectedSubject, setSelectedSubject] = useState('')
  const [selectedTopic, setSelectedTopic] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedContent, setGeneratedContent] = useState(null)
  const { t } = useLanguage()

  const subjects = [
    'Mathematics', 'Physics', 'Chemistry', 'Biology',
    'English', 'Amharic', 'History', 'Geography',
    'Civics', 'ICT'
  ]

  const topicsBySubject = {
    Mathematics: ['Algebra', 'Calculus', 'Geometry', 'Statistics', 'Trigonometry'],
    Physics: ['Mechanics', 'Electricity', 'Magnetism', 'Optics', 'Thermodynamics'],
    Chemistry: ['Organic Chemistry', 'Inorganic Chemistry', 'Physical Chemistry', 'Analytical Chemistry'],
    Biology: ['Genetics', 'Ecology', 'Human Biology', 'Cell Biology', 'Evolution'],
    English: ['Grammar', 'Literature', 'Writing Skills', 'Comprehension'],
    History: ['Ancient History', 'Medieval History', 'Modern History', 'Ethiopian History']
  }

  const tabs = [
    { id: 'concepts', label: 'Concept Explanation', icon: Lightbulb },
    { id: 'practice', label: 'Practice Questions', icon: Target },
    { id: 'resources', label: 'Learning Resources', icon: BookOpen },
    { id: 'strategies', label: 'Study Strategies', icon: Brain }
  ]

  const generateContent = () => {
    if (!selectedSubject || !selectedTopic) {
      alert('Please select both subject and topic')
      return
    }

    setIsGenerating(true)
    
    setTimeout(() => {
      const content = {
        id: Date.now(),
        subject: selectedSubject,
        topic: selectedTopic,
        timestamp: new Date().toLocaleString(),
        
        concepts: [
          'Core definition and fundamental principles',
          'Key formulas and equations to remember',
          'Real-world applications and examples',
          'Common misconceptions to avoid',
          'Step-by-step problem-solving approach'
        ],
        
        practiceQuestions: [
          {
            question: 'Explain the main concept in your own words',
            difficulty: 'Easy',
            points: 5
          },
          {
            question: 'Solve a typical problem using this concept',
            difficulty: 'Medium',
            points: 10
          },
          {
            question: 'Apply this concept to a real-world scenario',
            difficulty: 'Hard',
            points: 15
          },
          {
            question: 'Compare and contrast with related concepts',
            difficulty: 'Advanced',
            points: 20
          }
        ],
        
        resources: [
          'Textbook Chapter 4: Detailed explanation with diagrams',
          'Interactive simulation from Digital Library',
          'Video tutorial (15 minutes)',
          'Practice worksheet with answer key',
          'Additional reading materials'
        ],
        
        strategies: [
          'Break down complex concepts into smaller parts',
          'Use visual aids and diagrams for better understanding',
          'Practice with varied difficulty levels',
          'Review regularly with spaced repetition',
          'Teach the concept to someone else'
        ],
        
        assessment: {
          understanding: '85%',
          confidence: 'Medium',
          recommendations: [
            'Focus on application problems',
            'Review foundational concepts',
            'Practice timed exercises'
          ]
        }
      }
      
      setGeneratedContent(content)
      setIsGenerating(false)
    }, 2000)
  }

  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-4">AI Learning Support</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Get personalized learning assistance for any subject or topic
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="card p-6"
        >
          <h3 className="text-lg font-semibold mb-6">Learning Configuration</h3>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">Select Subject</label>
              <select
                value={selectedSubject}
                onChange={(e) => {
                  setSelectedSubject(e.target.value)
                  setSelectedTopic('')
                }}
                className="input-field"
              >
                <option value="">Choose a subject</option>
                {subjects.map(subject => (
                  <option key={subject} value={subject}>{subject}</option>
                ))}
              </select>
            </div>

            {selectedSubject && (
              <div>
                <label className="block text-sm font-medium mb-2">Select Topic</label>
                <select
                  value={selectedTopic}
                  onChange={(e) => setSelectedTopic(e.target.value)}
                  className="input-field"
                >
                  <option value="">Choose a topic</option>
                  {topicsBySubject[selectedSubject]?.map(topic => (
                    <option key={topic} value={topic}>{topic}</option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium mb-2">Learning Mode</label>
              <div className="space-y-2">
                {tabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg border text-left ${
                      activeTab === tab.id
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                        : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                    }`}
                  >
                    <tab.icon className="h-5 w-5" />
                    <span className="font-medium">{tab.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={generateContent}
              disabled={isGenerating || !selectedSubject || !selectedTopic}
              className="w-full btn-primary flex items-center justify-center gap-2"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Generating Content...
                </>
              ) : (
                <>
                  <Brain className="h-4 w-4" />
                  Get Learning Support
                </>
              )}
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-2"
        >
          {generatedContent ? (
            <div className="card p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-semibold">
                    {generatedContent.subject}: {generatedContent.topic}
                  </h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Generated on {generatedContent.timestamp}
                  </p>
                </div>
                <button className="btn-secondary flex items-center gap-2">
                  <Download className="h-4 w-4" />
                  Save
                </button>
              </div>

              <div className="space-y-6">
                {activeTab === 'concepts' && (
                  <div>
                    <h4 className="font-semibold mb-4 flex items-center gap-2">
                      <Lightbulb className="h-5 w-5 text-yellow-600" />
                      Concept Explanation
                    </h4>
                    <div className="space-y-3">
                      {generatedContent.concepts.map((concept, index) => (
                        <div key={index} className="p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
                          <div className="flex items-start gap-3">
                            <div className="h-6 w-6 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0">
                              <span className="text-sm font-medium text-blue-600 dark:text-blue-400">
                                {index + 1}
                              </span>
                            </div>
                            <p>{concept}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'practice' && (
                  <div>
                    <h4 className="font-semibold mb-4 flex items-center gap-2">
                      <Target className="h-5 w-5 text-green-600" />
                      Practice Questions
                    </h4>
                    <div className="space-y-4">
                      {generatedContent.practiceQuestions.map((q, index) => (
                        <div key={index} className="p-4 rounded-lg border">
                          <div className="flex items-center justify-between mb-3">
                            <span className="font-medium">Question {index + 1}</span>
                            <div className="flex items-center gap-4">
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                q.difficulty === 'Easy' 
                                  ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
                                  : q.difficulty === 'Medium'
                                  ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300'
                                  : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                              }`}>
                                {q.difficulty}
                              </span>
                              <span className="text-sm font-medium">{q.points} points</span>
                            </div>
                          </div>
                          <p>{q.question}</p>
                          <button className="mt-3 text-blue-600 hover:text-blue-800 dark:text-blue-400 text-sm font-medium">
                            View Solution →
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'resources' && (
                  <div>
                    <h4 className="font-semibold mb-4 flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-purple-600" />
                      Learning Resources
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {generatedContent.resources.map((resource, index) => (
                        <div key={index} className="p-4 rounded-lg border hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                          <div className="flex items-center gap-3 mb-2">
                            {resource.includes('Video') ? (
                              <PlayCircle className="h-5 w-5 text-red-600" />
                            ) : resource.includes('Textbook') ? (
                              <BookOpen className="h-5 w-5 text-blue-600" />
                            ) : (
                              <Lightbulb className="h-5 w-5 text-green-600" />
                            )}
                            <h5 className="font-medium">Resource {index + 1}</h5>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{resource}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'strategies' && (
                  <div>
                    <h4 className="font-semibold mb-4 flex items-center gap-2">
                      <Brain className="h-5 w-5 text-orange-600" />
                      Study Strategies
                    </h4>
                    <div className="space-y-3">
                      {generatedContent.strategies.map((strategy, index) => (
                        <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
                          <div className="h-6 w-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                            <span className="text-xs font-medium text-white">{index + 1}</span>
                          </div>
                          <div>
                            <p className="font-medium mb-1">Strategy {index + 1}</p>
                            <p>{strategy}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-8 pt-6 border-t dark:border-gray-800">
                <h4 className="font-semibold mb-4">Learning Assessment</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Understanding Level</p>
                    <p className="text-2xl font-bold mt-1">{generatedContent.assessment.understanding}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Confidence Level</p>
                    <p className="text-2xl font-bold mt-1">{generatedContent.assessment.confidence}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-purple-50 dark:bg-purple-900/20">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Recommendations</p>
                    <p className="text-sm font-medium mt-1">
                      {generatedContent.assessment.recommendations.length} suggestions
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="card p-6 h-full flex flex-col items-center justify-center text-center">
              <Brain className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Content Generated</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-6">
                Select a subject and topic to get personalized learning support
              </p>
              <div className="grid grid-cols-2 gap-4 text-sm text-gray-500 dark:text-gray-400">
                <div className="text-center">
                  <Lightbulb className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
                  <p>Concept Explanations</p>
                </div>
                <div className="text-center">
                  <Target className="h-8 w-8 text-green-500 mx-auto mb-2" />
                  <p>Practice Questions</p>
                </div>
                <div className="text-center">
                  <BookOpen className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                  <p>Learning Resources</p>
                </div>
                <div className="text-center">
                  <Brain className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                  <p>Study Strategies</p>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}

export default LearningSupport