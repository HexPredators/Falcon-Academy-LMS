import React from 'react'
import { motion } from 'framer-motion'
import { 
  Layers, 
  Filter, 
  Brain, 
  Users,
  Eye,
  BarChart3,
  Shield,
  Clock
} from 'lucide-react'
import { useLanguage } from '../../contexts/LanguageContext'

const HowWeWork = () => {
  const { t } = useLanguage()

  const features = [
    {
      icon: Layers,
      title: 'Hierarchical Access Control',
      description: 'Multi-level user permissions with strict data segregation',
      points: [
        'Super Admin: Full system control',
        'Directors: Grade-specific oversight',
        'Teachers: Subject and class management',
        'Students: Personal learning space',
        'Parents: Child progress monitoring'
      ]
    },
    {
      icon: Filter,
      title: 'Grade & Section Filtering',
      description: 'Content tailored to specific academic levels',
      points: [
        'Grade 9-12 with Ethiopian curriculum',
        'Stream specialization for Grades 11-12',
        'Section-based content delivery',
        'Term-based academic structure',
        'Subject categorization per national standards'
      ]
    },
    {
      icon: Brain,
      title: 'AI-Powered Learning',
      description: 'Intelligent assistance for teaching and learning',
      points: [
        'Lesson planning with curriculum alignment',
        'Personalized study schedules',
        'Adaptive learning path suggestions',
        'Practice question generation',
        'Progress analysis and recommendations'
      ]
    },
    {
      icon: Users,
      title: 'Parent-Child Integration',
      description: 'Real-time progress tracking for parents',
      points: [
        'Request-based child linking system',
        'Real-time assignment tracking',
        'Quiz score monitoring',
        'Reading progress updates',
        'Direct teacher communication'
      ]
    },
    {
      icon: BarChart3,
      title: 'Analytics Dashboard',
      description: 'Comprehensive performance insights',
      points: [
        'Role-specific analytics views',
        'Real-time progress tracking',
        'Comparative performance analysis',
        'Attendance monitoring',
        'Predictive performance insights'
      ]
    },
    {
      icon: Shield,
      title: 'Security & Privacy',
      description: 'Enterprise-grade security measures',
      points: [
        'OTP email verification',
        'Two-factor authentication',
        'Data encryption protocols',
        'Role-based access control',
        'Activity audit logging'
      ]
    }
  ]

  return (
    <div className="space-y-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold mb-4">How Falcon Academy Works</h2>
        <p className="text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
          A comprehensive digital learning ecosystem designed specifically for Ethiopian education,
          combining modern technology with pedagogical excellence.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, index) => (
          <motion.div
            key={feature.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="card p-6 hover:shadow-xl transition-shadow"
          >
            <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center mb-4">
              <feature.icon className="h-6 w-6 text-white" />
            </div>
            
            <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">{feature.description}</p>
            
            <ul className="space-y-2">
              {feature.points.map((point, idx) => (
                <li key={idx} className="flex items-start gap-2 text-sm">
                  <div className="h-1.5 w-1.5 rounded-full bg-blue-600 mt-1.5 flex-shrink-0" />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="card p-8"
      >
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold mb-4">Workflow Overview</h3>
          <p className="text-gray-600 dark:text-gray-400">
            From registration to graduation - a seamless learning journey
          </p>
        </div>

        <div className="relative">
          <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-gradient-to-b from-blue-500 to-purple-600" />
          
          <div className="space-y-12">
            {[
              {
                step: 1,
                title: 'Registration & Verification',
                description: 'Secure account creation with OTP email verification and role assignment',
                icon: Users
              },
              {
                step: 2,
                title: 'Profile Setup',
                description: 'Complete academic profile including grade, section, and stream selection',
                icon: Filter
              },
              {
                step: 3,
                title: 'Academic Engagement',
                description: 'Access assignments, quizzes, digital library, and interactive learning',
                icon: Brain
              },
              {
                step: 4,
                title: 'Progress Tracking',
                description: 'Real-time analytics, performance monitoring, and achievement tracking',
                icon: BarChart3
              },
              {
                step: 5,
                title: 'Parental Oversight',
                description: 'Parent-child linking and comprehensive progress reporting',
                icon: Eye
              }
            ].map((item, index) => (
              <div
                key={item.step}
                className={`flex items-center gap-8 ${
                  index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                }`}
              >
                <div className={`flex-1 ${index % 2 === 0 ? 'text-right' : 'text-left'}`}>
                  <h4 className="text-lg font-semibold mb-2">{item.title}</h4>
                  <p className="text-gray-600 dark:text-gray-400">{item.description}</p>
                </div>
                
                <div className="relative">
                  <div className="h-16 w-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xl font-bold">
                    {item.step}
                  </div>
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <item.icon className="h-6 w-6 text-white" />
                  </div>
                </div>
                
                <div className="flex-1" />
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  )
}

export default HowWeWork