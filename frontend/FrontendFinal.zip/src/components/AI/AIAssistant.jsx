import React, { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  MessageCircle, 
  X, 
  Send, 
  BookOpen, 
  Calendar,
  Lightbulb,
  HelpCircle,
  Sparkles
} from 'lucide-react'
import { useLanguage } from '../../contexts/LanguageContext'

const AIAssistant = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef(null)
  const { t } = useLanguage()

  const aiModules = [
    { id: 'how-we-work', icon: HelpCircle, label: t('howWeWork'), color: 'bg-blue-500' },
    { id: 'lesson-planner', icon: Calendar, label: t('lessonPlanner'), color: 'bg-green-500' },
    { id: 'study-planner', icon: BookOpen, label: t('studyPlanner'), color: 'bg-purple-500' },
    { id: 'learning-support', icon: Lightbulb, label: t('learningSupport'), color: 'bg-orange-500' }
  ]

  const initialGreeting = {
    id: 1,
    text: `👋 ${t('welcome')}! I'm Falcon AI Assistant. How can I help you today?`,
    isAI: true,
    timestamp: new Date()
  }

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([initialGreeting])
    }
  }, [isOpen])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleSend = async () => {
    if (!input.trim() || isLoading) return

    const userMessage = {
      id: messages.length + 1,
      text: input,
      isAI: false,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsLoading(true)

    setTimeout(() => {
      const aiResponse = {
        id: messages.length + 2,
        text: `I understand you're asking about "${input}". As an AI assistant for Falcon Academy, I can help you with:\n\n• Lesson planning and curriculum guidance\n• Study schedule optimization\n• Learning material recommendations\n• Academic progress analysis\n• Platform navigation assistance\n\nCould you be more specific about what you need help with?`,
        isAI: true,
        timestamp: new Date()
      }
      setMessages(prev => [...prev, aiResponse])
      setIsLoading(false)
    }, 1500)
  }

  const handleModuleClick = (moduleId) => {
    const moduleMessages = {
      'how-we-work': `📚 **${t('howWeWork')}**\n\nFalcon Academy DLMS works through:\n\n1. **Role-Based Access**: Each user has specific permissions\n2. **Grade & Section Filtering**: Content tailored to your class\n3. **AI Integration**: Smart assistance for learning and teaching\n4. **Parent Monitoring**: Real-time progress tracking\n5. **Ethiopian Curriculum**: Aligned with national standards`,
      'lesson-planner': `📝 **${t('lessonPlanner')}**\n\nI can help you create lesson plans for:\n\n• **Grade Levels**: 9-12 with stream specialization\n• **Subjects**: All Ethiopian curriculum subjects\n• **Duration**: From 45-minute sessions to full units\n• **Resources**: Digital library integration\n• **Assessment**: Built-in quiz and assignment tools`,
      'study-planner': `⏰ **${t('studyPlanner')}**\n\nLet me create a personalized study plan based on:\n\n• Your grade and stream (Natural/Social Science)\n• Upcoming assignments and quizzes\n• Previous performance data\n• Available study time\n• Learning preferences and pace`,
      'learning-support': `💡 **${t('learningSupport')}**\n\nI can provide:\n\n• **Concept Explanations**: Multiple teaching methods\n• **Practice Questions**: Adaptive difficulty levels\n• **Progress Analysis**: Identify strengths and weaknesses\n• **Resource Recommendations**: Books, videos, exercises\n• **Exam Preparation**: Strategies and revision plans`
    }

    const aiMessage = {
      id: messages.length + 1,
      text: moduleMessages[moduleId],
      isAI: true,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, aiMessage])
  }

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 h-14 w-14 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-shadow"
      >
        <MessageCircle className="h-6 w-6" />
        <div className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-green-500 animate-pulse" />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/50 z-40"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed bottom-24 right-6 z-50 w-96 h-[600px] rounded-2xl bg-white dark:bg-gray-900 shadow-2xl overflow-hidden"
            >
              <div className="h-full flex flex-col">
                <div className="p-4 border-b dark:border-gray-800">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                        <Sparkles className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Falcon AI Assistant</h3>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Online • Ready to help</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setIsOpen(false)}
                      className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto p-4">
                  <div className="grid grid-cols-2 gap-3 mb-6">
                    {aiModules.map((module) => (
                      <button
                        key={module.id}
                        onClick={() => handleModuleClick(module.id)}
                        className="flex flex-col items-center p-3 rounded-xl border dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                      >
                        <div className={`h-10 w-10 rounded-full ${module.color} flex items-center justify-center mb-2`}>
                          <module.icon className="h-5 w-5 text-white" />
                        </div>
                        <span className="text-xs font-medium text-center">{module.label}</span>
                      </button>
                    ))}
                  </div>

                  <div className="space-y-4">
                    {messages.map((message) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex ${message.isAI ? 'justify-start' : 'justify-end'}`}
                      >
                        <div
                          className={`max-w-[80%] rounded-2xl p-3 ${
                            message.isAI
                              ? 'bg-gray-100 dark:bg-gray-800 rounded-tl-none'
                              : 'bg-blue-600 text-white rounded-tr-none'
                          }`}
                        >
                          <p className="whitespace-pre-wrap">{message.text}</p>
                          <p className="text-xs opacity-75 mt-1">
                            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      </motion.div>
                    ))}
                    {isLoading && (
                      <div className="flex justify-start">
                        <div className="bg-gray-100 dark:bg-gray-800 rounded-2xl rounded-tl-none p-3">
                          <div className="flex gap-1">
                            <div className="h-2 w-2 rounded-full bg-blue-600 animate-bounce" />
                            <div className="h-2 w-2 rounded-full bg-blue-600 animate-bounce delay-75" />
                            <div className="h-2 w-2 rounded-full bg-blue-600 animate-bounce delay-150" />
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                </div>

                <div className="p-4 border-t dark:border-gray-800">
                  <div className="flex gap-2">
                    <textarea
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Ask me anything about learning, teaching, or the platform..."
                      className="flex-1 min-h-[44px] max-h-32 resize-none input-field"
                      rows="1"
                    />
                    <button
                      onClick={handleSend}
                      disabled={isLoading || !input.trim()}
                      className="btn-primary self-end disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Send className="h-4 w-4" />
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 text-center">
                    Press Enter to send • Shift+Enter for new line
                  </p>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}

export default AIAssistant