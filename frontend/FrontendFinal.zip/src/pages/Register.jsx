import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import StudentRegistration from '../components/Auth/StudentRegistration';
import TeacherRegistration from '../components/Auth/TeacherRegistration';
import ParentRegistration from '../components/Auth/ParentRegistration';

const Register = () => {
  const [activeRole, setActiveRole] = useState('student');

  const roles = [
    { id: 'student', name: 'Student', icon: '🎓' },
    { id: 'teacher', name: 'Teacher', icon: '👨‍🏫' },
    { id: 'parent', name: 'Parent', icon: '👪' }
  ];

  const renderRegistrationForm = () => {
    switch (activeRole) {
      case 'student':
        return <StudentRegistration />;
      case 'teacher':
        return <TeacherRegistration />;
      case 'parent':
        return <ParentRegistration />;
      default:
        return <StudentRegistration />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="mx-auto h-12 w-12 bg-blue-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-xl">F</span>
          </div>
          <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
            Join Falcon Academy LMS
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Create your account to access the digital learning platform
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="border-b border-gray-200">
            <div className="flex">
              {roles.map((role) => (
                <button
                  key={role.id}
                  onClick={() => setActiveRole(role.id)}
                  className={`flex-1 px-6 py-4 text-sm font-medium text-center border-b-2 transition-colors ${
                    activeRole === role.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <span className="text-lg block mb-1">{role.icon}</span>
                  {role.name}
                </button>
              ))}
            </div>
          </div>

          <div className="p-6">
            {renderRegistrationForm()}
          </div>

          <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
            <p className="text-sm text-gray-600 text-center">
              Already have an account?{' '}
              <Link to="/login" className="font-medium text-blue-600 hover:text-blue-500">
                Sign in here
              </Link>
            </p>
          </div>
        </div>

        <div className="mt-6 text-center text-xs text-gray-500">
          <p>By registering, you agree to our Terms of Service and Privacy Policy</p>
        </div>
      </div>
    </div>
  );
};

export default Register;