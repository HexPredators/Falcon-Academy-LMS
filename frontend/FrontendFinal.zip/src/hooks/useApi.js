import { useState, useCallback } from 'react'
import axios from 'axios'

export const useApi = () => {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const request = useCallback(async (method, url, data = null, config = {}) => {
    setLoading(true)
    setError(null)

    try {
      const response = await axios({
        method,
        url,
        data,
        ...config
      })
      setLoading(false)
      return { data: response.data, success: true }
    } catch (err) {
      setLoading(false)
      setError(err.response?.data?.message || 'An error occurred')
      return { error: err.response?.data?.message || 'An error occurred', success: false }
    }
  }, [])

  return { loading, error, request }
}
export default useApi.js