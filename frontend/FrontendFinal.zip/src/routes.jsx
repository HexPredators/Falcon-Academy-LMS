import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './hooks/useAuth'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Assignments from './pages/Assignments'
import Quizzes from './pages/Quizzes'
import Library from './pages/Library'
import Messages from './pages/Messages'
import News from './pages/News'
import Analytics from './pages/Analytics'
import Settings from './pages/Settings'
import Profile from './pages/Profile'

function PrivateRoute({ children, allowedRoles }) {
  const { user, loading } = useAuth()
  
  if (loading) return <div>Loading...</div>
  
  if (!user) return <Navigate to="/login" />
  
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/dashboard" />
  }
  
  return children
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      
      <Route path="/dashboard" element={
        <PrivateRoute>
          <Dashboard />
        </PrivateRoute>
      } />
      
      <Route path="/assignments" element={
        <PrivateRoute allowedRoles={['student', 'teacher', 'director', 'admin']}>
          <Assignments />
        </PrivateRoute>
      } />
      
      <Route path="/quizzes" element={
        <PrivateRoute allowedRoles={['student', 'teacher', 'director', 'admin']}>
          <Quizzes />
        </PrivateRoute>
      } />
      
      <Route path="/library" element={
        <PrivateRoute>
          <Library />
        </PrivateRoute>
      } />
      
      <Route path="/messages" element={
        <PrivateRoute>
          <Messages />
        </PrivateRoute>
      } />
      
      <Route path="/news" element={<News />} />
      
      <Route path="/analytics" element={
        <PrivateRoute allowedRoles={['teacher', 'director', 'admin', 'parent']}>
          <Analytics />
        </PrivateRoute>
      } />
      
      <Route path="/settings" element={
        <PrivateRoute>
          <Settings />
        </PrivateRoute>
      } />
      
      <Route path="/profile" element={
        <PrivateRoute>
          <Profile />
        </PrivateRoute>
      } />
      
      <Route path="/" element={<Navigate to="/dashboard" />} />
    </Routes>
  )
}

export default AppRoutes