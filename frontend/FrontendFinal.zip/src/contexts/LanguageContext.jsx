import React, { createContext, useState, useContext, useEffect } from 'react'
import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'

const LanguageContext = createContext()

export const useLanguage = () => {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider')
  }
  return context
}

const resources = {
  en: {
    translation: {
      welcome: 'Welcome to Falcon Academy',
      login: 'Login',
      register: 'Register',
      dashboard: 'Dashboard',
      assignments: 'Assignments',
      quizzes: 'Quizzes',
      library: 'Digital Library',
      messages: 'Messages',
      news: 'News',
      analytics: 'Analytics',
      settings: 'Settings',
      profile: 'Profile',
      logout: 'Logout',
      grade: 'Grade',
      section: 'Section',
      subject: 'Subject',
      teacher: 'Teacher',
      student: 'Student',
      parent: 'Parent',
      director: 'Director',
      admin: 'Admin',
      naturalScience: 'Natural Science',
      socialScience: 'Social Science',
      create: 'Create',
      edit: 'Edit',
      delete: 'Delete',
      submit: 'Submit',
      cancel: 'Cancel',
      save: 'Save',
      search: 'Search',
      filter: 'Filter',
      viewAll: 'View All',
      dueDate: 'Due Date',
      status: 'Status',
      completed: 'Completed',
      pending: 'Pending',
      graded: 'Graded',
      score: 'Score',
      average: 'Average',
      progress: 'Progress',
      attendance: 'Attendance',
      performance: 'Performance',
      aiAssistant: 'AI Assistant',
      lessonPlanner: 'Lesson Planner',
      studyPlanner: 'Study Planner',
      learningSupport: 'Learning Support',
      howWeWork: 'How We Work'
    }
  },
  am: {
    translation: {
      welcome: 'እንኳን ወደ ፋልኮን አካዳሚ በደህና መጡ',
      login: 'ግባ',
      register: 'ተመዝገብ',
      dashboard: 'ዳሽቦርድ',
      assignments: 'እድገት',
      quizzes: 'ፈተናዎች',
      library: 'ዲጂታል ቤተ-መጻሕፍት',
      messages: 'መልዕክቶች',
      news: 'ዜና',
      analytics: 'ትንተና',
      settings: 'ቅንብሮች',
      profile: 'መገለጫ',
      logout: 'ውጣ',
      grade: 'ክፍል',
      section: 'ዘርፍ',
      subject: 'ትምህርት',
      teacher: 'መምህር',
      student: 'ተማሪ',
      parent: 'ወላጅ',
      director: 'ዳይሬክተር',
      admin: 'አስተዳዳሪ',
      naturalScience: 'ተፈጥሮ ሳይንስ',
      socialScience: 'ማህበራዊ ሳይንስ',
      create: 'ፍጠር',
      edit: 'አርትዕ',
      delete: 'ሰርዝ',
      submit: 'አስገባ',
      cancel: 'ሰርዝ',
      save: 'አስቀምጥ',
      search: 'ፈልግ',
      filter: 'አጣራ',
      viewAll: 'ሁሉንም ይመልከቱ',
      dueDate: 'የሚያልቅበት ቀን',
      status: 'ሁኔታ',
      completed: 'ተጠናቀቀ',
      pending: 'በመጠባበቅ ላይ',
      graded: 'ደረጃ ተሰጠው',
      score: 'ነጥብ',
      average: 'አማካኝ',
      progress: 'እድገት',
      attendance: 'መገኘት',
      performance: 'አፈፃፀም',
      aiAssistant: 'AI ረዳት',
      lessonPlanner: 'የትምህርት እቅድ',
      studyPlanner: 'የማጥኛ እቅድ',
      learningSupport: 'የማሰልጠኛ ድጋፍ',
      howWeWork: 'እንዴት እንሰራለን'
    }
  },
  om: {
    translation: {
      welcome: 'Baga nagaan dhuftan Falcon Academy',
      login: 'Seeni',
      register: 'Galmeessi',
      dashboard: 'Daashboorduu',
      assignments: 'Hojiiwwan',
      quizzes: 'Qorannoo',
      library: 'Kitaaba Dijiitaalaa',
      messages: 'Ergaa',
      news: 'Oduu',
      analytics: 'Qorannoo',
      settings: 'Saajjii',
      profile: 'Seenaa',
      logout: 'Ba\'i',
      grade: 'Darajaa',
      section: 'Qooda',
      subject: 'Ogummaa',
      teacher: 'Barnootaa',
      student: 'Barataa',
      parent: 'Haadha/Abbaa',
      director: 'Qajeelaa',
      admin: 'Administrator',
      naturalScience: 'Saayinsii Uumamaa',
      socialScience: 'Saayinsii Hawaasaa',
      create: 'Uumi',
      edit: 'Gulaali',
      delete: 'Haqu',
      submit: 'Kenne',
      cancel: 'Dhiisi',
      save: 'Qabsi',
      search: 'Barbaadi',
      filter: 'Filtaara',
      viewAll: 'Hunda Ilaali',
      dueDate: 'Guyyaa Xumura',
      status: 'Haala',
      completed: 'Xumuramte',
      pending: 'Eegamaa',
      graded: 'Sadarkaan Kenname',
      score: 'Pooyintii',
      average: 'Walakkaa',
      progress: 'Ooluu',
      attendance: 'Argamuu',
      performance: 'Hojii',
      aiAssistant: 'Gargaaraa AI',
      lessonPlanner: 'Karoora Barumsaa',
      studyPlanner: 'Karoora Qo\'annoo',
      learningSupport: 'Gargaarsa Barumsaa',
      howWeWork: 'Akkamitti Hojjanna'
    }
  },
  ti: {
    translation: {
      welcome: 'እንቋዕ ናብ ፋልኮን ኣካዳሚ ብድሓን መጻእኩም',
      login: 'እቶ',
      register: 'ተመዝገብ',
      dashboard: 'ዳሽቦርድ',
      assignments: 'ናይ ምዃን',
      quizzes: 'ፈተናታት',
      library: 'ዲጂታል ቤተ ክትባት',
      messages: 'መልእኽቲ',
      news: 'ዜና',
      analytics: 'ትንተና',
      settings: 'ቅንጅት',
      profile: 'መግለጺ',
      logout: 'ውጻእ',
      grade: 'ደረጃ',
      section: 'ክፍሊ',
      subject: 'ትምህርቲ',
      teacher: 'ምሁር',
      student: 'ተማሃራይ',
      parent: 'ወለዲ',
      director: 'ዳይሬክተር',
      admin: 'ኣስተዳደሪ',
      naturalScience: 'ተፈጥሮኣዊ ሳይንስ',
      socialScience: 'ማሕበራዊ ሳይንስ',
      create: 'ፈጥር',
      edit: 'ኣርትዕ',
      delete: 'ሰርዝ',
      submit: 'ኣቕርብ',
      cancel: 'ኣትርፍ',
      save: 'ኣቐምጥ',
      search: 'ድለይ',
      filter: 'ፈልይ',
      viewAll: 'ኩሉ ርአ',
      dueDate: 'ዕለት ዝውዕል',
      status: 'ስግኣት',
      completed: 'ተወዲኡ',
      pending: 'ተጸበየ',
      graded: 'ደረጃ ተዋሂቡ',
      score: 'ነጥቢ',
      average: 'መንካሕ',
      progress: 'ምዕባለ',
      attendance: 'ምህላው',
      performance: 'ናይ ምስራሕ',
      aiAssistant: 'AI ሓጋዚ',
      lessonPlanner: 'ናይ ትምህርቲ ውጥን',
      studyPlanner: 'ናይ መጽናዕቲ ውጥን',
      learningSupport: 'ደገፍ መጽናዕቲ',
      howWeWork: 'ከመይ ኢና ንሰርሕ'
    }
  }
}

i18n.use(initReactI18next).init({
  resources,
  lng: localStorage.getItem('language') || 'en',
  fallbackLng: 'en',
  interpolation: {
    escapeValue: false
  }
})

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(localStorage.getItem('language') || 'en')

  const changeLanguage = (lng) => {
    setLanguage(lng)
    i18n.changeLanguage(lng)
    localStorage.setItem('language', lng)
  }

  const t = (key) => i18n.t(key)

  return (
    <LanguageContext.Provider value={{ language, changeLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export { LanguageContext }
export default LanguageContext