import React from 'react'
import { motion } from 'framer-motion'
import { 
  Brain, 
  Clock, 
  TrendingUp, 
  AlertCircle,
  CheckCircle,
  XCircle
} from 'lucide-react'
import Header from '../components/Common/Header'
import { useLanguage } from '../contexts/LanguageContext'
import AIAssistant from '../components/AI/AIAssistant'

const Quizzes = () => {
  const { t } = useLanguage()

  const quizzes = [
    {
      id: 1,
      title: 'Mathematics Quiz - Calculus',
      subject: 'Mathematics',
      grade: '11',
      duration: '30 mins',
      questions: 20,
      status: 'available',
      score: null,
      dueDate: '2024-01-15'
    },
    {
      id: 2,
      title: 'Physics Quiz - Mechanics',
      subject: 'Physics',
      grade: '11',
      duration: '45 mins',
      questions: 25,
      status: 'completed',
      score: 85,
      dueDate: '2024-01-10'
    },
    {
      id: 3,
      title: 'Chemistry Quiz - Organic',
      subject: 'Chemistry',
      grade: '11',
      duration: '35 mins',
      questions: 22,
      status: 'upcoming',
      score: null,
      dueDate: '2024-01-20'
    },
    {
      id: 4,
      title: 'Biology Quiz - Genetics',
      subject: 'Biology',
      grade: '12',
      duration: '40 mins',
      questions: 30,
      status: 'available',
      score: null,
      dueDate: '2024-01-18'
    }
  ]

  const performanceStats = [
    { subject: 'Mathematics', score: 88, attempts: 5, average: 85 },
    { subject: 'Physics', score: 92, attempts: 4, average: 78 },
    { subject: 'Chemistry', score: 85, attempts: 6, average: 82 },
    { subject: 'Biology', score: 90, attempts: 3, average: 75 }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 dark:from-gray-900 dark:to-gray-950">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          <div>
            <h1 className="text-3xl font-bold mb-2">{t('quizzes')}</h1>
            <p className="text-gray-600 dark:text-gray-400">
              Test your knowledge with interactive quizzes
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Brain, label: 'Total Quizzes', value: '12', color: 'bg-blue-500' },
              { icon: Clock, label: 'Average Time', value: '28m', color: 'bg-green-500' },
              { icon: TrendingUp, label: 'Avg Score', value: '86%', color: 'bg-purple-500' },
              { icon: CheckCircle, label: 'Completed', value: '8', color: 'bg-orange-500' }
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="card p-6"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{stat.label}</p>
                    <p className="text-2xl font-bold mt-2">{stat.value}</p>
                  </div>
                  <div className={`h-12 w-12 rounded-full ${stat.color} flex items-center justify-center`}>
                    <stat.icon className="h-6 w-6 text-white" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="card p-6 lg:col-span-2"
            >
              <h3 className="text-lg font-semibold mb-6">Available Quizzes</h3>
              <div className="space-y-4">
                {quizzes.map((quiz) => (
                  <div
                    key={quiz.id}
                    className="flex items-center justify-between p-4 rounded-lg border hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                        <Brain className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-medium">{quiz.title}</h4>
                        <div className="flex items-center gap-3 text-sm text-gray-500 dark:text-gray-400 mt-1">
                          <span>{quiz.subject}</span>
                          <span>•</span>
                          <span>Grade {quiz.grade}</span>
                          <span>•</span>
                          <span>{quiz.questions} questions</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4" />
                          <span className="text-sm">{quiz.duration}</span>
                        </div>
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          Due: {quiz.dueDate}
                        </span>
                      </div>
                      <button className={`px-4 py-2 rounded-lg text-sm font-medium ${
                        quiz.status === 'available'
                          ? 'bg-blue-600 text-white hover:bg-blue-700'
                          : quiz.status === 'completed'
                          ? 'bg-green-600 text-white hover:bg-green-700'
                          : 'bg-gray-200 dark:bg-gray-800 text-gray-600 dark:text-gray-400'
                      }`}>
                        {quiz.status === 'available' ? 'Start Quiz' : 
                         quiz.status === 'completed' ? `Score: ${quiz.score}%` : 'Upcoming'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="card p-6"
            >
              <h3 className="text-lg font-semibold mb-6">Performance by Subject</h3>
              <div className="space-y-4">
                {performanceStats.map((stat, index) => (
                  <div key={stat.subject} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{stat.subject}</span>
                      <span className="font-bold">{stat.score}%</span>
                    </div>
                    <div className="h-2 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${stat.score}%` }}
                        transition={{ duration: 1, delay: index * 0.1 }}
                        className="h-full bg-gradient-to-r from-blue-500 to-purple-600"
                      />
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                      <span>{stat.attempts} attempts</span>
                      <span>Class avg: {stat.average}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="card p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold">Quiz Tips & Strategies</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Improve your quiz performance with these tips
                </p>
              </div>
              <AlertCircle className="h-6 w-6 text-blue-600" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                <div className="h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-800 flex items-center justify-center mb-3">
                  <Clock className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <h4 className="font-medium mb-2">Time Management</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Allocate time based on question weight and difficulty
                </p>
              </div>
              <div className="p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                <div className="h-10 w-10 rounded-full bg-green-100 dark:bg-green-800 flex items-center justify-center mb-3">
                  <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
                </div>
                <h4 className="font-medium mb-2">Review Questions</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Always review answers before submission
                </p>
              </div>
              <div className="p-4 rounded-lg bg-purple-50 dark:bg-purple-900/20">
                <div className="h-10 w-10 rounded-full bg-purple-100 dark:bg-purple-800 flex items-center justify-center mb-3">
                  <Brain className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                </div>
                <h4 className="font-medium mb-2">Focus on Weak Areas</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Identify and improve in challenging topics
                </p>
              </div>
              <div className="p-4 rounded-lg bg-orange-50 dark:bg-orange-900/20">
                <div className="h-10 w-10 rounded-full bg-orange-100 dark:bg-orange-800 flex items-center justify-center mb-3">
                  <TrendingUp className="h-5 w-5 text-orange-600 dark:text-orange-400" />
                </div>
                <h4 className="font-medium mb-2">Track Progress</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Monitor improvements through analytics
                </p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
      <AIAssistant />
    </div>
  )
}

export default Quizzes