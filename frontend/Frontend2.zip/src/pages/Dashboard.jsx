import React from 'react'
import { motion } from 'framer-motion'
import { 
  BookOpen, 
  Users, 
  BarChart3, 
  Calendar, 
  FileText,
  Award,
  Clock,
  TrendingUp
} from 'lucide-react'
import Header from '../components/Common/Header'
import Sidebar from '../components/Common/Sidebar'
import { useAuth } from '../hooks/useAuth'
import { useLanguage } from '../contexts/LanguageContext'
import StudentDashboard from '../components/Dashboard/StudentDashboard'
import TeacherDashboard from '../components/Dashboard/TeacherDashboard'
import DirectorDashboard from '../components/Dashboard/DirectorDashboard'
import ParentDashboard from '../components/Dashboard/ParentDashboard'
import AdminDashboard from '../components/Dashboard/AdminDashboard'

const Dashboard = () => {
  const { user } = useAuth()
  const { t } = useLanguage()

  const getDashboardByRole = () => {
    switch (user?.role) {
      case 'student':
        return <StudentDashboard />
      case 'teacher':
        return <TeacherDashboard />
      case 'director':
        return <DirectorDashboard />
      case 'parent':
        return <ParentDashboard />
      case 'admin':
        return <AdminDashboard />
      default:
        return <StudentDashboard />
    }
  }

  const stats = [
    { icon: BookOpen, label: 'Total Assignments', value: '12', change: '+2' },
    { icon: FileText, label: 'Completed', value: '8', change: '+3' },
    { icon: Award, label: 'Average Score', value: '85%', change: '+5%' },
    { icon: TrendingUp, label: 'Progress', value: '92%', change: '+8%' }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 dark:from-gray-900 dark:to-gray-950">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="mb-8">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              {t('welcome')}, {user?.name}!
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              {user?.role === 'student' && 'Track your learning progress and upcoming assignments'}
              {user?.role === 'teacher' && 'Manage your classes and monitor student performance'}
              {user?.role === 'director' && 'Oversee academic progress and institutional analytics'}
              {user?.role === 'parent' && 'Monitor your child\'s academic performance and progress'}
              {user?.role === 'admin' && 'Manage system-wide operations and user administration'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="card p-6 hover:shadow-lg transition-shadow"
              >
                <div className="flex items-center justify-between">
                  <div className="p-3 rounded-full bg-blue-100 dark:bg-blue-900/30">
                    <stat.icon className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <span className="text-sm font-medium text-green-600 dark:text-green-400">
                    {stat.change}
                  </span>
                </div>
                <h3 className="text-2xl font-bold mt-4">{stat.value}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{stat.label}</p>
              </motion.div>
            ))}
          </div>

          {getDashboardByRole()}
        </motion.div>
      </div>
    </div>
  )
}

export default Dashboard