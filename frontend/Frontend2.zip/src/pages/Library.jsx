import React from 'react'
import Header from '../components/Common/Header'
import DigitalLibrary from '../components/Library/DigitalLibrary'
import AIAssistant from '../components/AI/AIAssistant'

const Library = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 dark:from-gray-900 dark:to-gray-950">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <DigitalLibrary />
      </div>
      <AIAssistant />
    </div>
  )
}

export default Library