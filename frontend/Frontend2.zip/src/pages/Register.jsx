import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { 
  User, 
  Mail, 
  Lock, 
  BookOpen,
  Users,
  Eye,
  EyeOff,
  ChevronRight
} from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import { useLanguage } from '../contexts/LanguageContext'

const Register = () => {
  const [step, setStep] = useState(1)
  const [userType, setUserType] = useState('student')
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    grade: '',
    section: '',
    stream: '',
    favId: '',
    phone: '',
    subjects: []
  })
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { register } = useAuth()
  const { t } = useLanguage()
  const navigate = useNavigate()

  const userTypes = [
    { id: 'student', icon: User, label: 'Student', description: 'Register as a student' },
    { id: 'teacher', icon: Users, label: 'Teacher', description: 'Register as a teacher' },
    { id: 'parent', icon: Users, label: 'Parent', description: 'Register as a parent' }
  ]

  const grades = ['9', '10', '11', '12']
  const sections = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
  const streams = ['Natural Science', 'Social Science']
  const subjects = ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'History', 'Geography']

  const handleUserTypeSelect = (type) => {
    setUserType(type)
    setStep(2)
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubjectToggle = (subject) => {
    setFormData(prev => ({
      ...prev,
      subjects: prev.subjects.includes(subject)
        ? prev.subjects.filter(s => s !== subject)
        : [...prev.subjects, subject]
    }))
  }

  const validateStep1 = () => {
    if (!formData.name.trim()) return 'Name is required'
    if (!formData.email.trim()) return 'Email is required'
    if (!formData.password) return 'Password is required'
    if (formData.password.length < 8) return 'Password must be at least 8 characters'
    if (formData.password !== formData.confirmPassword) return 'Passwords do not match'
    return null
  }

  const validateStep2 = () => {
    if (userType === 'student') {
      if (!formData.grade) return 'Grade is required'
      if (!formData.section) return 'Section is required'
      if (!formData.favId) return 'FAV/ID is required'
    }
    if (userType === 'teacher') {
      if (!formData.subjects.length) return 'At least one subject is required'
    }
    return null
  }

  const handleNext = () => {
    if (step === 1) {
      const error = validateStep1()
      if (error) {
        alert(error)
        return
      }
      setStep(2)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const error = validateStep2()
    if (error) {
      alert(error)
      return
    }

    setIsLoading(true)
    const registrationData = {
      ...formData,
      role: userType,
      grade: userType === 'student' ? formData.grade : null,
      section: userType === 'student' ? formData.section : null,
      stream: userType === 'student' && formData.grade >= 11 ? formData.stream : null
    }

    const result = await register(registrationData)
    setIsLoading(false)
    
    if (result.success) {
      navigate('/dashboard')
    }
  }

  return (
    <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-4xl"
      >
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-4">
            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
              <BookOpen className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold">Falcon Academy</span>
          </Link>
          <h1 className="text-3xl font-bold mb-2">Create Account</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Join Falcon Academy's digital learning platform
          </p>
        </div>

        <div className="card overflow-hidden">
          <div className="p-8">
            {step === 1 ? (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="space-y-6"
              >
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-semibold mb-2">Select Account Type</h2>
                  <p className="text-gray-600 dark:text-gray-400">
                    Choose the type of account you want to create
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                  {userTypes.map((type) => (
                    <button
                      key={type.id}
                      onClick={() => handleUserTypeSelect(type.id)}
                      className={`p-6 rounded-xl border-2 transition-all text-left ${
                        userType === type.id
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                          : 'border-gray-200 dark:border-gray-800 hover:border-blue-300 dark:hover:border-blue-700'
                      }`}
                    >
                      <type.icon className={`h-8 w-8 mb-4 ${
                        userType === type.id
                          ? 'text-blue-600'
                          : 'text-gray-400'
                      }`} />
                      <h3 className="font-semibold mb-2">{type.label}</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {type.description}
                      </p>
                    </button>
                  ))}
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        className="input-field pl-10"
                        placeholder="John Doe"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="input-field pl-10"
                        placeholder="student@falconacademy.edu.et"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Password</label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                        <input
                          type={showPassword ? 'text' : 'password'}
                          name="password"
                          value={formData.password}
                          onChange={handleInputChange}
                          className="input-field pl-10 pr-10"
                          placeholder="••••••••"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2"
                        >
                          {showPassword ? (
                            <EyeOff className="h-5 w-5 text-gray-400" />
                          ) : (
                            <Eye className="h-5 w-5 text-gray-400" />
                          )}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Confirm Password</label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                        <input
                          type="password"
                          name="confirmPassword"
                          value={formData.confirmPassword}
                          onChange={handleInputChange}
                          className="input-field pl-10"
                          placeholder="••••••••"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <Link
                    to="/login"
                    className="text-blue-600 hover:text-blue-800 dark:text-blue-400"
                  >
                    Already have an account? Sign in
                  </Link>
                  <button
                    onClick={handleNext}
                    className="btn-primary flex items-center gap-2"
                  >
                    Continue
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-semibold mb-2">
                    {userType === 'student' && 'Student Information'}
                    {userType === 'teacher' && 'Teacher Information'}
                    {userType === 'parent' && 'Parent Information'}
                  </h2>
                  <p className="text-gray-600 dark:text-gray-400">
                    Provide additional details for your account
                  </p>
                </div>

                {userType === 'student' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Grade Level</label>
                        <select
                          name="grade"
                          value={formData.grade}
                          onChange={handleInputChange}
                          className="input-field"
                        >
                          <option value="">Select Grade</option>
                          {grades.map(grade => (
                            <option key={grade} value={grade}>Grade {grade}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Section</label>
                        <select
                          name="section"
                          value={formData.section}
                          onChange={handleInputChange}
                          className="input-field"
                        >
                          <option value="">Select Section</option>
                          {sections.map(section => (
                            <option key={section} value={section}>Section {section}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {formData.grade >= 11 && (
                      <div>
                        <label className="block text-sm font-medium mb-2">Stream</label>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {streams.map(stream => (
                            <button
                              key={stream}
                              type="button"
                              onClick={() => setFormData(prev => ({ ...prev, stream }))}
                              className={`p-4 rounded-lg border-2 text-left ${
                                formData.stream === stream
                                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                                  : 'border-gray-200 dark:border-gray-800'
                              }`}
                            >
                              <h3 className="font-medium">{stream}</h3>
                              <p className="text-sm text-gray-500 dark:text-gray-400">
                                {stream === 'Natural Science' ? 'Focus on Sciences & Mathematics' : 'Focus on Social Studies & Humanities'}
                              </p>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    <div>
                      <label className="block text-sm font-medium mb-2">FAV/ID Number</label>
                      <input
                        type="text"
                        name="favId"
                        value={formData.favId}
                        onChange={handleInputChange}
                        className="input-field"
                        placeholder="Enter your FAV/ID number"
                      />
                    </div>
                  </div>
                )}

                {userType === 'teacher' && (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Phone Number</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="input-field"
                        placeholder="+251 91 234 5678"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Select Subjects</label>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        {subjects.map(subject => (
                          <button
                            key={subject}
                            type="button"
                            onClick={() => handleSubjectToggle(subject)}
                            className={`p-3 rounded-lg border text-sm ${
                              formData.subjects.includes(subject)
                                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                                : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                            }`}
                          >
                            {subject}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Grades You Teach</label>
                      <div className="flex flex-wrap gap-2">
                        {grades.map(grade => (
                          <button
                            key={grade}
                            type="button"
                            onClick={() => handleSubjectToggle(`Grade ${grade}`)}
                            className={`px-3 py-2 rounded-lg border text-sm ${
                              formData.subjects.includes(`Grade ${grade}`)
                                ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400'
                                : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                            }`}
                          >
                            Grade {grade}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {userType === 'parent' && (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Phone Number</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="input-field"
                        placeholder="+251 91 234 5678"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Link Child Account</label>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                        You can link your child's account after registration
                      </p>
                      <div className="p-4 rounded-lg border border-dashed border-gray-300 dark:border-gray-700">
                        <div className="text-center">
                          <Users className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            Link child account from Parent Dashboard after registration
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <button
                    onClick={() => setStep(1)}
                    className="btn-secondary"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleSubmit}
                    disabled={isLoading}
                    className="btn-primary flex items-center gap-2"
                  >
                    {isLoading ? 'Creating Account...' : 'Create Account'}
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </motion.div>
            )}
          </div>
        </div>

        <div className="mt-6 text-center text-sm text-gray-500 dark:text-gray-400">
          <p>
            By creating an account, you agree to our{' '}
            <a href="#" className="text-blue-600 hover:text-blue-800 dark:text-blue-400">
              Terms of Service
            </a>{' '}
            and{' '}
            <a href="#" className="text-blue-600 hover:text-blue-800 dark:text-blue-400">
              Privacy Policy
            </a>
          </p>
        </div>
      </motion.div>
    </div>
  )
}

export default Register