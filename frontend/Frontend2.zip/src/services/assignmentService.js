// frontend/src/services/assignmentService.js
import api from './api';

class AssignmentService {
  // Get assignments based on user role
  async getAssignments(role, userId, filters = {}) {
    const params = new URLSearchParams();
    
    Object.entries(filters).forEach(([key, value]) => {
      if (value) params.append(key, value);
    });

    const endpoint = role === 'teacher' 
      ? `/assignments/teacher/${userId}`
      : `/assignments/student/${userId}`;

    return api.get(`${endpoint}?${params.toString()}`);
  }

  // Create new assignment (teacher only)
  async createAssignment(assignmentData) {
    const formData = new FormData();
    
    // Append all fields to form data
    Object.entries(assignmentData).forEach(([key, value]) => {
      if (value !== null && value !== undefined) {
        if (key === 'tags' || key === 'resources' || key === 'rubric') {
          formData.append(key, JSON.stringify(value));
        } else if (key === 'assignment_file' && value instanceof File) {
          formData.append(key, value);
        } else {
          formData.append(key, value);
        }
      }
    });

    return api.post('/assignments', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  }

  // Submit assignment (student only)
  async submitAssignment({ assignmentId, submissionText, studentNotes, submissionFile }) {
    const formData = new FormData();
    
    formData.append('submission_text', submissionText || '');
    formData.append('student_notes', studentNotes || '');

    if (submissionFile instanceof File) {
      formData.append('submission_file', submissionFile);
    }

    return api.post(`/assignments/${assignmentId}/submit`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  }

  // Grade assignment (teacher only)
  async gradeAssignment(submissionId, gradeData) {
    return api.post(`/assignments/submissions/${submissionId}/grade`, gradeData);
  }

  // Get assignment analytics
  async getAssignmentAnalytics(assignmentId) {
    return api.get(`/assignments/${assignmentId}/analytics`);
  }

  // Get submission details
  async getSubmissionDetails(submissionId) {
    return api.get(`/assignments/submissions/${submissionId}`);
  }

  // Download assignment file
  async downloadAssignmentFile(assignmentId) {
    return api.get(`/assignments/${assignmentId}/download`, {
      responseType: 'blob'
    });
  }

  // Get submissions for grading (teacher only)
  async getSubmissionsForGrading(assignmentId, filters = {}) {
    const params = new URLSearchParams(filters);
    return api.get(`/assignments/${assignmentId}/submissions?${params.toString()}`);
  }
}

export const assignmentService = new AssignmentService();
export default assignmentService.js