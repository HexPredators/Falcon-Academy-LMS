import api from './api';

export const authService = {
  async login(email, password) {
    const response = await api.post('/auth/login', { email, password });
    return response.data;
  },

  async registerStudent(studentData) {
    const response = await api.post('/auth/register/student', studentData);
    return response.data;
  },

  async registerTeacher(teacherData) {
    const response = await api.post('/auth/register/teacher', teacherData);
    return response.data;
  },

  async verifyOTP(email, otp) {
    const response = await api.post('/auth/verify-otp', { email, otp });
    return response.data;
  },

  async resendOTP(email) {
    const response = await api.post('/auth/resend-otp', { email });
    return response.data;
  },

  async getCurrentUser() {
    const response = await api.get('/auth/me');
    return response.data.user;
  },

  async updateProfile(userId, profileData) {
    const response = await api.put(`/users/${userId}`, profileData);
    return response.data;
  }
};
export default authService.js