import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  X, 
  Upload, 
  Calendar,
  Eye,
  Globe,
  School,
  Users,
  Award
} from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'

const CreateNews = ({ onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    category: 'school',
    visibility: 'public',
    targetGrades: [],
    targetSections: [],
    priority: 'medium',
    image: null,
    attachments: [],
    publishDate: '',
    expireDate: ''
  })
  const { user } = useAuth()

  const categories = [
    { id: 'school', label: 'School News', icon: School },
    { id: 'grade', label: 'Grade Specific', icon: Users },
    { id: 'event', label: 'Event', icon: Calendar },
    { id: 'achievement', label: 'Achievement', icon: Award }
  ]

  const visibilities = [
    { id: 'public', label: 'Public', icon: Globe, description: 'Visible to everyone' },
    { id: 'school', label: 'School Only', icon: School, description: 'Visible after login' },
    { id: 'grade', label: 'Grade Specific', icon: Users, description: 'Visible to specific grades' },
    { id: 'section', label: 'Section Specific', icon: Eye, description: 'Visible to specific sections' }
  ]

  const priorities = [
    { id: 'high', label: 'High', color: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300' },
    { id: 'medium', label: 'Medium', color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300' },
    { id: 'low', label: 'Low', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' }
  ]

  const grades = ['9', '10', '11', '12']
  const sections = ['A', 'B', 'C', 'D', 'E', 'F', 'G']

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleGradeToggle = (grade) => {
    setFormData(prev => ({
      ...prev,
      targetGrades: prev.targetGrades.includes(grade)
        ? prev.targetGrades.filter(g => g !== grade)
        : [...prev.targetGrades, grade]
    }))
  }

  const handleSectionToggle = (section) => {
    setFormData(prev => ({
      ...prev,
      targetSections: prev.targetSections.includes(section)
        ? prev.targetSections.filter(s => s !== section)
        : [...prev.targetSections, section]
    }))
  }

  const handleFileUpload = (e, type) => {
    const file = e.target.files[0]
    if (file) {
      if (type === 'image') {
        if (!file.type.startsWith('image/')) {
          alert('Please upload an image file')
          return
        }
        setFormData(prev => ({ ...prev, image: file }))
      } else {
        setFormData(prev => ({
          ...prev,
          attachments: [...prev.attachments, file]
        }))
      }
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    const newsData = {
      ...formData,
      author: user.name,
      authorRole: user.role,
      createdAt: new Date().toISOString(),
      views: 0
    }

    console.log('News created:', newsData)
    
    if (onSuccess) {
      onSuccess(newsData)
    }
    
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-4xl max-h-[90vh] overflow-y-auto"
      >
        <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl">
          <div className="p-6 border-b dark:border-gray-800">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-semibold">Create News Announcement</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Share important updates with the school community
                </p>
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">
                Title *
              </label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                className="input-field"
                placeholder="Enter news title..."
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Content *
              </label>
              <textarea
                name="content"
                value={formData.content}
                onChange={handleInputChange}
                rows="6"
                className="input-field"
                placeholder="Write your news content here..."
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Category
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {categories.map(category => (
                    <button
                      key={category.id}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, category: category.id }))}
                      className={`p-3 rounded-lg border text-left ${
                        formData.category === category.id
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                          : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                      }`}
                    >
                      <category.icon className="h-5 w-5 mb-2" />
                      <span className="font-medium">{category.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Priority
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {priorities.map(priority => (
                    <button
                      key={priority.id}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, priority: priority.id }))}
                      className={`px-3 py-2 rounded-lg text-sm font-medium ${
                        formData.priority === priority.id
                          ? `${priority.color} border-2 border-current`
                          : 'border border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                      }`}
                    >
                      {priority.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Visibility
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {visibilities.map(visibility => (
                  <button
                    key={visibility.id}
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, visibility: visibility.id }))}
                    className={`p-3 rounded-lg border text-left ${
                      formData.visibility === visibility.id
                        ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                        : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                    }`}
                  >
                    <visibility.icon className="h-5 w-5 mb-2" />
                    <div>
                      <span className="font-medium">{visibility.label}</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {visibility.description}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {formData.visibility === 'grade' && (
              <div>
                <label className="block text-sm font-medium mb-2">
                  Target Grades
                </label>
                <div className="flex flex-wrap gap-2">
                  {grades.map(grade => (
                    <button
                      key={grade}
                      type="button"
                      onClick={() => handleGradeToggle(grade)}
                      className={`px-4 py-2 rounded-lg border ${
                        formData.targetGrades.includes(grade)
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                          : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                      }`}
                    >
                      Grade {grade}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {formData.visibility === 'section' && (
              <div>
                <label className="block text-sm font-medium mb-2">
                  Target Sections
                </label>
                <div className="flex flex-wrap gap-2">
                  {sections.map(section => (
                    <button
                      key={section}
                      type="button"
                      onClick={() => handleSectionToggle(section)}
                      className={`px-4 py-2 rounded-lg border ${
                        formData.targetSections.includes(section)
                          ? 'border-green-500 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400'
                          : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                      }`}
                    >
                      Section {section}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Featured Image
                </label>
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-6 text-center">
                  <input
                    type="file"
                    id="image-upload"
                    className="hidden"
                    accept="image/*"
                    onChange={(e) => handleFileUpload(e, 'image')}
                  />
                  <label
                    htmlFor="image-upload"
                    className="cursor-pointer flex flex-col items-center"
                  >
                    {formData.image ? (
                      <>
                        <img
                          src={URL.createObjectURL(formData.image)}
                          alt="Preview"
                          className="h-32 w-full object-cover rounded-lg mb-4"
                        />
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Click to change image
                        </p>
                      </>
                    ) : (
                      <>
                        <Upload className="h-12 w-12 text-gray-400 mb-4" />
                        <p className="font-medium mb-1">Upload Featured Image</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Click to upload (optional)
                        </p>
                      </>
                    )}
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Attachments
                </label>
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-6 text-center">
                  <input
                    type="file"
                    id="attachment-upload"
                    className="hidden"
                    multiple
                    onChange={(e) => handleFileUpload(e, 'attachment')}
                  />
                  <label
                    htmlFor="attachment-upload"
                    className="cursor-pointer flex flex-col items-center"
                  >
                    <Upload className="h-12 w-12 text-gray-400 mb-4" />
                    <p className="font-medium mb-1">Upload Attachments</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Click to upload files (optional)
                    </p>
                  </label>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Publish Date
                </label>
                <input
                  type="datetime-local"
                  name="publishDate"
                  value={formData.publishDate}
                  onChange={handleInputChange}
                  className="input-field"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Expiry Date (Optional)
                </label>
                <input
                  type="datetime-local"
                  name="expireDate"
                  value={formData.expireDate}
                  onChange={handleInputChange}
                  className="input-field"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-6 border-t dark:border-gray-800">
              <button
                type="button"
                onClick={onClose}
                className="btn-secondary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-primary"
              >
                Publish Announcement
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  )
}

export default CreateNews