import React from 'react'
import { motion } from 'framer-motion'

const Card = ({ 
  children, 
  className = '', 
  hover = false,
  padding = true,
  border = true,
  shadow = true
}) => {
  return (
    <motion.div
      whileHover={hover ? { y: -2 } : {}}
      className={`
        rounded-xl
        ${border ? 'border dark:border-gray-800' : ''}
        ${shadow ? 'shadow-sm hover:shadow-md' : ''}
        ${padding ? 'p-6' : ''}
        bg-white dark:bg-gray-900
        transition-all duration-200
        ${className}
      `}
    >
      {children}
    </motion.div>
  )
}

export default Card