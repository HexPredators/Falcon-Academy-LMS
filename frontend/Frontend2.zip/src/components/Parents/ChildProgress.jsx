import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  TrendingUp, 
  BookOpen,
  Clock,
  Award,
  Calendar,
  Download,
  Eye
} from 'lucide-react'
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts'

const ChildProgress = ({ childId }) => {
  const [timeRange, setTimeRange] = useState('monthly')
  
  const childData = {
    id: childId || 1,
    name: 'Samuel Getachew',
    grade: '11',
    section: 'A',
    stream: 'Natural Science',
    overallAverage: 89,
    attendance: 98,
    completedAssignments: 48,
    totalAssignments: 50
  }

  const performanceData = [
    { month: 'Sep', assignments: 85, quizzes: 78, average: 82 },
    { month: 'Oct', assignments: 88, quizzes: 82, average: 85 },
    { month: 'Nov', assignments: 92, quizzes: 85, average: 89 },
    { month: 'Dec', assignments: 90, quizzes: 88, average: 87 },
    { month: 'Jan', assignments: 94, quizzes: 90, average: 92 }
  ]

  const subjectPerformance = [
    { subject: 'Mathematics', score: 92, classAvg: 85, improvement: '+7%' },
    { subject: 'Physics', score: 88, classAvg: 78, improvement: '+10%' },
    { subject: 'Chemistry', score: 85, classAvg: 82, improvement: '+3%' },
    { subject: 'English', score: 87, classAvg: 80, improvement: '+7%' },
    { subject: 'Amharic', score: 90, classAvg: 85, improvement: '+5%' }
  ]

  const recentActivities = [
    { id: 1, activity: 'Submitted Math Assignment', score: '95/100', date: 'Today', time: '10:30 AM' },
    { id: 2, activity: 'Completed Physics Quiz', score: '88/100', date: 'Yesterday', time: '2:15 PM' },
    { id: 3, activity: 'English Essay Graded', score: '90/100', date: '2 days ago', time: '11:45 AM' },
    { id: 4, activity: 'Chemistry Lab Report', score: 'Pending', date: '3 days ago', time: '9:20 AM' }
  ]

  const upcomingAssignments = [
    { id: 1, subject: 'Mathematics', title: 'Calculus Homework', dueDate: 'Tomorrow', points: 100 },
    { id: 2, subject: 'Physics', title: 'Mechanics Quiz', dueDate: 'Jan 20', points: 50 },
    { id: 3, subject: 'Chemistry', title: 'Lab Report', dueDate: 'Jan 22', points: 75 }
  ]

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-semibold">{childData.name}'s Progress</h3>
          <p className="text-gray-600 dark:text-gray-400">
            Grade {childData.grade} • Section {childData.section} • {childData.stream}
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="input-field"
          >
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="quarterly">Quarterly</option>
          </select>
          <button className="btn-secondary flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="card p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Overall Average</p>
              <p className="text-2xl font-bold mt-2">{childData.overallAverage}%</p>
            </div>
            <TrendingUp className="h-8 w-8 text-green-600" />
          </div>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.02 }}
          className="card p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Attendance</p>
              <p className="text-2xl font-bold mt-2">{childData.attendance}%</p>
            </div>
            <Calendar className="h-8 w-8 text-blue-600" />
          </div>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.02 }}
          className="card p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Assignments</p>
              <p className="text-2xl font-bold mt-2">
                {childData.completedAssignments}/{childData.totalAssignments}
              </p>
            </div>
            <BookOpen className="h-8 w-8 text-purple-600" />
          </div>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.02 }}
          className="card p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Class Rank</p>
              <p className="text-2xl font-bold mt-2">8th</p>
            </div>
            <Award className="h-8 w-8 text-orange-600" />
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="card p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h4 className="font-semibold">Performance Trend</h4>
            <TrendingUp className="h-5 w-5 text-blue-600" />
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip />
                <Line type="monotone" dataKey="average" stroke="#3B82F6" strokeWidth={3} />
                <Line type="monotone" dataKey="assignments" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="quizzes" stroke="#8B5CF6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="card p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h4 className="font-semibold">Subject Performance</h4>
            <BookOpen className="h-5 w-5 text-green-600" />
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={subjectPerformance}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="subject" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip />
                <Bar dataKey="score" name="Student Score" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="classAvg" name="Class Average" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="card p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h4 className="font-semibold">Recent Activities</h4>
            <Eye className="h-5 w-5 text-purple-600" />
          </div>
          <div className="space-y-4">
            {recentActivities.map(activity => (
              <div
                key={activity.id}
                className="flex items-center justify-between p-4 rounded-lg border hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
              >
                <div>
                  <h5 className="font-medium">{activity.activity}</h5>
                  <div className="flex items-center gap-3 text-sm text-gray-500 dark:text-gray-400 mt-1">
                    <Clock className="h-3 w-3" />
                    <span>{activity.date}</span>
                    <span>•</span>
                    <span>{activity.time}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`font-bold ${
                    activity.score === 'Pending' 
                      ? 'text-yellow-600 dark:text-yellow-400'
                      : 'text-green-600 dark:text-green-400'
                  }`}>
                    {activity.score}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="card p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h4 className="font-semibold">Upcoming Assignments</h4>
            <Calendar className="h-5 w-5 text-orange-600" />
          </div>
          <div className="space-y-4">
            {upcomingAssignments.map(assignment => (
              <div
                key={assignment.id}
                className="flex items-center justify-between p-4 rounded-lg border hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
              >
                <div>
                  <h5 className="font-medium">{assignment.title}</h5>
                  <div className="flex items-center gap-3 text-sm text-gray-500 dark:text-gray-400 mt-1">
                    <span>{assignment.subject}</span>
                    <span>•</span>
                    <span>Due: {assignment.dueDate}</span>
                    <span>•</span>
                    <span>{assignment.points} points</span>
                  </div>
                </div>
                <button className="text-blue-600 hover:text-blue-800 dark:text-blue-400 text-sm font-medium">
                  View Details
                </button>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  )
}

export default ChildProgress