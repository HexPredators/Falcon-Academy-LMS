import React from 'react'
import { motion } from 'framer-motion'
import { 
  Calendar, 
  Clock, 
  FileText, 
  Upload,
  CheckCircle,
  AlertCircle
} from 'lucide-react'

const AssignmentCard = ({ assignment }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300'
      case 'graded': return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
      case 'submitted': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300'
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300'
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'graded': return <CheckCircle className="h-4 w-4" />
      case 'submitted': return <Upload className="h-4 w-4" />
      default: return <AlertCircle className="h-4 w-4" />
    }
  }

  return (
    <motion.div
      whileHover={{ scale: 1.01 }}
      className="card p-4 hover:shadow-lg transition-shadow"
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-3">
            <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
              <FileText className="h-5 w-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold">{assignment.title}</h3>
              <div className="flex items-center gap-3 text-sm text-gray-500 dark:text-gray-400">
                <span>{assignment.subject}</span>
                <span>•</span>
                <span>Grade {assignment.grade}</span>
                <span>•</span>
                <span>Section {assignment.section}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span>Due: {assignment.dueDate}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>{assignment.points} points</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-end gap-3">
          <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-2 ${getStatusColor(assignment.status)}`}>
            {getStatusIcon(assignment.status)}
            {assignment.status.charAt(0).toUpperCase() + assignment.status.slice(1)}
          </span>
          
          {assignment.submitted ? (
            <span className="text-sm text-green-600 dark:text-green-400">
              Score: {assignment.score || 'Grading...'}
            </span>
          ) : (
            <button className="btn-primary text-sm px-4 py-1">
              {assignment.status === 'pending' ? 'Submit Now' : 'View Details'}
            </button>
          )}
        </div>
      </div>
    </motion.div>
  )
}

export default AssignmentCard