import React from 'react'
import { motion } from 'framer-motion'
import { 
  BookOpen, 
  Star, 
  Eye, 
  Download,
  Clock
} from 'lucide-react'

const BookCard = ({ book }) => {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="card overflow-hidden group"
    >
      <div className={`h-48 ${book.coverColor} relative`}>
        <div className="absolute inset-0 flex items-center justify-center">
          <BookOpen className="h-16 w-16 text-white/30" />
        </div>
        <div className="absolute top-4 right-4">
          <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-sm text-white text-xs font-medium">
            Grade {book.grade}
          </span>
        </div>
      </div>
      
      <div className="p-6">
        <div className="mb-4">
          <h3 className="font-semibold text-lg mb-1 line-clamp-1">{book.title}</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">{book.author}</p>
          <div className="flex items-center gap-2 text-sm">
            <span className="px-2 py-1 rounded bg-gray-100 dark:bg-gray-800">
              {book.subject}
            </span>
            <span className="px-2 py-1 rounded bg-gray-100 dark:bg-gray-800">
              {book.pages} pages
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 text-yellow-500" />
              <span>{book.rating}</span>
            </div>
            <div className="flex items-center gap-1">
              <Eye className="h-4 w-4" />
              <span>{book.reads.toLocaleString()}</span>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg">
              <BookOpen className="h-4 w-4" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg">
              <Download className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  )
}

export default BookCard