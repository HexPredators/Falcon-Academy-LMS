import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Calendar,
  Clock,
  BookOpen,
  Target,
  TrendingUp,
  CheckCircle,
  AlertCircle,
  Download
} from 'lucide-react'
import { useLanguage } from '../../contexts/LanguageContext'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts'

const StudyPlanner = () => {
  const [formData, setFormData] = useState({
    grade: '',
    stream: '',
    subjects: [],
    studyHours: '2',
    startDate: '',
    endDate: '',
    goals: ''
  })
  const [generatedPlan, setGeneratedPlan] = useState(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const { t } = useLanguage()

  const subjects = [
    { id: 'math', name: 'Mathematics', hours: 6, color: '#3B82F6' },
    { id: 'physics', name: 'Physics', hours: 5, color: '#8B5CF6' },
    { id: 'chemistry', name: 'Chemistry', hours: 4, color: '#10B981' },
    { id: 'biology', name: 'Biology', hours: 4, color: '#F59E0B' },
    { id: 'english', name: 'English', hours: 3, color: '#EF4444' },
    { id: 'amharic', name: 'Amharic', hours: 3, color: '#EC4899' },
    { id: 'history', name: 'History', hours: 2, color: '#6366F1' },
    { id: 'geography', name: 'Geography', hours: 2, color: '#14B8A6' }
  ]

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubjectToggle = (subjectId) => {
    setFormData(prev => ({
      ...prev,
      subjects: prev.subjects.includes(subjectId)
        ? prev.subjects.filter(id => id !== subjectId)
        : [...prev.subjects, subjectId]
    }))
  }

  const generateStudyPlan = () => {
    setIsGenerating(true)
    
    setTimeout(() => {
      const selectedSubjectsData = subjects.filter(subject => 
        formData.subjects.includes(subject.id)
      )
      
      const totalHours = selectedSubjectsData.reduce((sum, subject) => sum + subject.hours, 0)
      const dailyHours = parseInt(formData.studyHours)
      const studyDays = Math.ceil(totalHours / dailyHours)
      
      const plan = {
        id: Date.now(),
        grade: formData.grade,
        stream: formData.stream,
        totalSubjects: selectedSubjectsData.length,
        totalStudyHours: totalHours,
        dailyStudyHours: dailyHours,
        estimatedCompletion: studyDays + ' days',
        startDate: formData.startDate || new Date().toISOString().split('T')[0],
        endDate: new Date(Date.now() + studyDays * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        subjects: selectedSubjectsData,
        weeklySchedule: [
          { day: 'Monday', subjects: ['Mathematics', 'Physics'], hours: dailyHours },
          { day: 'Tuesday', subjects: ['Chemistry', 'Biology'], hours: dailyHours },
          { day: 'Wednesday', subjects: ['English', 'Amharic'], hours: dailyHours },
          { day: 'Thursday', subjects: ['Mathematics', 'Physics'], hours: dailyHours },
          { day: 'Friday', subjects: ['Chemistry', 'Biology'], hours: dailyHours },
          { day: 'Saturday', subjects: ['Revision', 'Practice'], hours: dailyHours / 2 },
          { day: 'Sunday', subjects: ['Rest', 'Review'], hours: 1 }
        ],
        studyTips: [
          'Study in 45-minute intervals with 15-minute breaks',
          'Review previous material before starting new topics',
          'Practice with past exam papers',
          'Use active recall techniques',
          'Join study groups for difficult topics'
        ],
        resources: [
          'Textbooks and class notes',
          'Digital library resources',
          'Practice worksheets',
          'Educational videos',
          'AI-generated practice questions'
        ]
      }
      
      setGeneratedPlan(plan)
      setIsGenerating(false)
    }, 1500)
  }

  const studyData = generatedPlan?.subjects.map(subject => ({
    name: subject.name,
    hours: subject.hours,
    color: subject.color
  })) || []

  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-4">AI Study Planner</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Create personalized study schedules optimized for academic success
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="card p-6"
        >
          <h3 className="text-lg font-semibold mb-6">Study Plan Configuration</h3>
          
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Grade Level</label>
                <select
                  name="grade"
                  value={formData.grade}
                  onChange={handleInputChange}
                  className="input-field"
                >
                  <option value="">Select Grade</option>
                  <option value="9">Grade 9</option>
                  <option value="10">Grade 10</option>
                  <option value="11">Grade 11</option>
                  <option value="12">Grade 12</option>
                </select>
              </div>

              {formData.grade >= 11 && (
                <div>
                  <label className="block text-sm font-medium mb-2">Stream</label>
                  <select
                    name="stream"
                    value={formData.stream}
                    onChange={handleInputChange}
                    className="input-field"
                  >
                    <option value="">Select Stream</option>
                    <option value="natural">Natural Science</option>
                    <option value="social">Social Science</option>
                  </select>
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Subjects to Focus On</label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {subjects.map(subject => (
                  <button
                    key={subject.id}
                    type="button"
                    onClick={() => handleSubjectToggle(subject.id)}
                    className={`p-3 rounded-lg border text-sm flex items-center gap-2 ${
                      formData.subjects.includes(subject.id)
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                        : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                    }`}
                  >
                    <div
                      className="h-3 w-3 rounded-full"
                      style={{ backgroundColor: subject.color }}
                    />
                    {subject.name}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Daily Study Hours Available
              </label>
              <div className="flex items-center gap-4">
                <select
                  name="studyHours"
                  value={formData.studyHours}
                  onChange={handleInputChange}
                  className="input-field"
                >
                  <option value="1">1 hour</option>
                  <option value="2">2 hours</option>
                  <option value="3">3 hours</option>
                  <option value="4">4 hours</option>
                  <option value="5">5+ hours</option>
                </select>
                <Clock className="h-5 w-5 text-gray-400" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Start Date</label>
                <input
                  type="date"
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleInputChange}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Target End Date</label>
                <input
                  type="date"
                  name="endDate"
                  value={formData.endDate}
                  onChange={handleInputChange}
                  className="input-field"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Study Goals</label>
              <textarea
                name="goals"
                value={formData.goals}
                onChange={handleInputChange}
                rows="3"
                className="input-field"
                placeholder="Enter your specific study goals (e.g., improve math scores, complete all assignments early, etc.)"
              />
            </div>

            <button
              onClick={generateStudyPlan}
              disabled={isGenerating || !formData.grade || formData.subjects.length === 0}
              className="w-full btn-primary flex items-center justify-center gap-2"
            >
              {isGenerating ? (
                <>
                  <Clock className="h-4 w-4 animate-spin" />
                  Generating Plan...
                </>
              ) : (
                <>
                  <Calendar className="h-4 w-4" />
                  Generate Study Plan
                </>
              )}
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          {generatedPlan ? (
            <div className="card p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-semibold">Your Study Plan</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {generatedPlan.startDate} to {generatedPlan.endDate}
                  </p>
                </div>
                <button
                  onClick={() => window.print()}
                  className="btn-secondary flex items-center gap-2"
                >
                  <Download className="h-4 w-4" />
                  Export
                </button>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Subjects</p>
                    <p className="text-2xl font-bold">{generatedPlan.totalSubjects}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Total Hours</p>
                    <p className="text-2xl font-bold">{generatedPlan.totalStudyHours}h</p>
                  </div>
                  <div className="p-4 rounded-lg bg-purple-50 dark:bg-purple-900/20">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Daily Hours</p>
                    <p className="text-2xl font-bold">{generatedPlan.dailyStudyHours}h</p>
                  </div>
                  <div className="p-4 rounded-lg bg-orange-50 dark:bg-orange-900/20">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Duration</p>
                    <p className="text-2xl font-bold">{generatedPlan.estimatedCompletion}</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-4">Subject Time Allocation</h4>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={studyData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="name" stroke="#9CA3AF" />
                        <YAxis stroke="#9CA3AF" />
                        <Tooltip />
                        <Bar dataKey="hours" radius={[4, 4, 0, 0]}>
                          {studyData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Weekly Schedule</h4>
                  <div className="space-y-2">
                    {generatedPlan.weeklySchedule.map((day, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 rounded-lg border"
                      >
                        <div>
                          <span className="font-medium">{day.day}</span>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {day.subjects.join(', ')}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-gray-400" />
                          <span>{day.hours}h</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <Target className="h-4 w-4 text-green-600" />
                      Study Tips
                    </h4>
                    <ul className="space-y-2">
                      {generatedPlan.studyTips.map((tip, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm">
                          <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <BookOpen className="h-4 w-4 text-blue-600" />
                      Recommended Resources
                    </h4>
                    <ul className="space-y-2">
                      {generatedPlan.resources.map((resource, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm">
                          <div className="h-4 w-4 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                            <TrendingUp className="h-3 w-3 text-blue-600 dark:text-blue-400" />
                          </div>
                          <span>{resource}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="card p-6 h-full flex flex-col items-center justify-center text-center">
              <Calendar className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Study Plan Generated</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-6">
                Configure your study preferences to generate a personalized plan
              </p>
              <div className="space-y-3 text-sm text-gray-500 dark:text-gray-400">
                <p className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  Optimized for Ethiopian curriculum
                </p>
                <p className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  Personalized time allocation
                </p>
                <p className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  Includes study tips and resources
                </p>
                <p className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  Trackable weekly schedule
                </p>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}

export default StudyPlanner