import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Calendar, 
  Clock, 
  BookOpen,
  Target,
  Download,
  RefreshCw,
  Plus,
  Trash2
} from 'lucide-react'
import { useLanguage } from '../../contexts/LanguageContext'

const LessonPlanner = () => {
  const [formData, setFormData] = useState({
    subject: '',
    grade: '',
    topic: '',
    duration: '45',
    objectives: '',
    methodology: 'lecture',
    resources: []
  })
  const [generatedPlan, setGeneratedPlan] = useState(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const { t } = useLanguage()

  const subjects = [
    'Mathematics', 'Physics', 'Chemistry', 'Biology',
    'English', 'Amharic', 'History', 'Geography',
    'Civics', 'ICT', 'Physical Education'
  ]

  const grades = ['9', '10', '11', '12']
  const methodologies = [
    { id: 'lecture', label: 'Lecture', icon: BookOpen },
    { id: 'discussion', label: 'Group Discussion', icon: Users },
    { id: 'activity', label: 'Practical Activity', icon: Activity },
    { id: 'demonstration', label: 'Demonstration', icon: Eye },
    { id: 'problem-solving', label: 'Problem Solving', icon: Target }
  ]

  const resourceTypes = [
    'Textbook', 'Whiteboard', 'Projector', 'Lab Equipment',
    'Worksheets', 'Digital Presentation', 'Online Resources',
    'Assessment Tools', 'Reference Materials'
  ]

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleResourceToggle = (resource) => {
    setFormData(prev => ({
      ...prev,
      resources: prev.resources.includes(resource)
        ? prev.resources.filter(r => r !== resource)
        : [...prev.resources, resource]
    }))
  }

  const generateLessonPlan = () => {
    setIsGenerating(true)
    
    setTimeout(() => {
      const plan = {
        id: Date.now(),
        subject: formData.subject,
        grade: formData.grade,
        topic: formData.topic || 'Sample Topic',
        duration: formData.duration,
        date: new Date().toLocaleDateString(),
        sections: [
          {
            title: 'Introduction (10 minutes)',
            activities: [
              'Review previous lesson concepts',
              'Present learning objectives',
              'Engage students with a thought-provoking question',
              'Connect to real-world applications'
            ]
          },
          {
            title: 'Core Content (25 minutes)',
            activities: [
              'Present key concepts with examples',
              'Interactive demonstration',
              'Student participation activities',
              'Check for understanding'
            ]
          },
          {
            title: 'Practice & Application (15 minutes)',
            activities: [
              'Guided practice exercises',
              'Group problem-solving',
              'Individual practice time',
              'Teacher support and feedback'
            ]
          },
          {
            title: 'Conclusion & Assessment (10 minutes)',
            activities: [
              'Review key takeaways',
              'Quick formative assessment',
              'Preview next lesson',
              'Assign homework/practice'
            ]
          }
        ],
        objectives: formData.objectives.split('\n').filter(obj => obj.trim()) || [
          'Understand key concepts',
          'Apply knowledge to solve problems',
          'Develop critical thinking skills'
        ],
        resources: formData.resources.length ? formData.resources : ['Textbook', 'Whiteboard', 'Worksheets'],
        assessment: [
          'Formative: In-class questions and participation',
          'Summative: End-of-lesson quiz',
          'Homework assignment'
        ],
        differentiation: [
          'Advanced students: Extended challenge problems',
          'Struggling students: Additional guided practice',
          'ELL students: Visual aids and simplified language'
        ]
      }
      
      setGeneratedPlan(plan)
      setIsGenerating(false)
    }, 2000)
  }

  const downloadPlan = () => {
    const element = document.createElement('a')
    const file = new Blob([JSON.stringify(generatedPlan, null, 2)], {type: 'application/json'})
    element.href = URL.createObjectURL(file)
    element.download = `lesson-plan-${generatedPlan.subject}-${generatedPlan.grade}.json`
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-4">AI Lesson Planner</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Generate comprehensive lesson plans aligned with Ethiopian curriculum standards
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="card p-6"
        >
          <h3 className="text-lg font-semibold mb-6">Plan Configuration</h3>
          
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Subject</label>
                <select
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  className="input-field"
                >
                  <option value="">Select Subject</option>
                  {subjects.map(subject => (
                    <option key={subject} value={subject}>{subject}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Grade Level</label>
                <select
                  name="grade"
                  value={formData.grade}
                  onChange={handleInputChange}
                  className="input-field"
                >
                  <option value="">Select Grade</option>
                  {grades.map(grade => (
                    <option key={grade} value={grade}>Grade {grade}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Topic</label>
              <input
                type="text"
                name="topic"
                value={formData.topic}
                onChange={handleInputChange}
                className="input-field"
                placeholder="e.g., Introduction to Calculus, Photosynthesis, World History"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Duration (minutes)</label>
              <div className="flex items-center gap-4">
                <select
                  name="duration"
                  value={formData.duration}
                  onChange={handleInputChange}
                  className="input-field"
                >
                  <option value="45">45 minutes</option>
                  <option value="90">90 minutes (double period)</option>
                  <option value="120">120 minutes (extended)</option>
                </select>
                <Clock className="h-5 w-5 text-gray-400" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Learning Objectives</label>
              <textarea
                name="objectives"
                value={formData.objectives}
                onChange={handleInputChange}
                rows="3"
                className="input-field"
                placeholder="Enter specific learning objectives (one per line)"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Teaching Methodology</label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {methodologies.map(method => (
                  <button
                    key={method.id}
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, methodology: method.id }))}
                    className={`p-3 rounded-lg border text-sm flex items-center gap-2 ${
                      formData.methodology === method.id
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                        : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                    }`}
                  >
                    <method.icon className="h-4 w-4" />
                    {method.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Required Resources</label>
              <div className="flex flex-wrap gap-2">
                {resourceTypes.map(resource => (
                  <button
                    key={resource}
                    type="button"
                    onClick={() => handleResourceToggle(resource)}
                    className={`px-3 py-2 rounded-lg border text-sm ${
                      formData.resources.includes(resource)
                        ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400'
                        : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                    }`}
                  >
                    {resource}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={generateLessonPlan}
              disabled={isGenerating || !formData.subject || !formData.grade}
              className="w-full btn-primary flex items-center justify-center gap-2"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Generating Plan...
                </>
              ) : (
                <>
                  <Calendar className="h-4 w-4" />
                  Generate Lesson Plan
                </>
              )}
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          {generatedPlan ? (
            <div className="card p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-semibold">Generated Lesson Plan</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {generatedPlan.date} • {generatedPlan.duration} minutes
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={downloadPlan}
                    className="btn-secondary flex items-center gap-2"
                  >
                    <Download className="h-4 w-4" />
                    Export
                  </button>
                  <button
                    onClick={() => setGeneratedPlan(null)}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <div className="space-y-6">
                <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                  <h4 className="font-semibold mb-2">Lesson Overview</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Subject</p>
                      <p className="font-medium">{generatedPlan.subject}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Grade</p>
                      <p className="font-medium">Grade {generatedPlan.grade}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Topic</p>
                      <p className="font-medium">{generatedPlan.topic}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Duration</p>
                      <p className="font-medium">{generatedPlan.duration} minutes</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Lesson Structure</h4>
                  <div className="space-y-4">
                    {generatedPlan.sections.map((section, index) => (
                      <div key={index} className="border-l-4 border-blue-500 pl-4">
                        <h5 className="font-medium mb-2">{section.title}</h5>
                        <ul className="space-y-1">
                          {section.activities.map((activity, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm">
                              <div className="h-1.5 w-1.5 rounded-full bg-blue-600 mt-1.5 flex-shrink-0" />
                              <span>{activity}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3">Learning Objectives</h4>
                    <ul className="space-y-2">
                      {generatedPlan.objectives.map((obj, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm">
                          <Target className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                          <span>{obj}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-3">Required Resources</h4>
                    <div className="flex flex-wrap gap-2">
                      {generatedPlan.resources.map((resource, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-1 bg-gray-100 dark:bg-gray-800 rounded-full text-sm"
                        >
                          {resource}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Assessment Strategies</h4>
                  <ul className="space-y-2">
                    {generatedPlan.assessment.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm">
                        <BookOpen className="h-4 w-4 text-purple-600 flex-shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Differentiation Strategies</h4>
                  <ul className="space-y-2">
                    {generatedPlan.differentiation.map((strategy, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm">
                        <div className="h-4 w-4 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Plus className="h-3 w-3 text-orange-600 dark:text-orange-400" />
                        </div>
                        <span>{strategy}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ) : (
            <div className="card p-6 h-full flex flex-col items-center justify-center text-center">
              <Calendar className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Lesson Plan Generated</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-6">
                Configure your lesson details and generate a comprehensive plan
              </p>
              <div className="space-y-3 text-sm text-gray-500 dark:text-gray-400">
                <p>• Aligned with Ethiopian curriculum</p>
                <p>• Time-optimized lesson structure</p>
                <p>• Multiple teaching methodologies</p>
                <p>• Assessment strategies included</p>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}

export default LessonPlanner