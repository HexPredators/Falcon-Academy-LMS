import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Plus, 
  Trash2, 
  Clock,
  Hash,
  Edit2,
  Eye
} from 'lucide-react'

const QuizForm = ({ onSubmit, onCancel, initialData }) => {
  const [formData, setFormData] = useState(initialData || {
    title: '',
    subject: '',
    grade: '',
    section: '',
    description: '',
    duration: 30,
    questions: [],
    passingScore: 60,
    isPublished: false
  })

  const [currentQuestion, setCurrentQuestion] = useState({
    text: '',
    type: 'multiple-choice',
    options: ['', '', '', ''],
    correctAnswer: 0,
    points: 1
  })

  const subjects = [
    'Mathematics', 'Physics', 'Chemistry', 'Biology',
    'English', 'Amharic', 'History', 'Geography',
    'Civics', 'ICT', 'Physical Education'
  ]

  const grades = ['9', '10', '11', '12']
  const sections = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
  const questionTypes = [
    { id: 'multiple-choice', label: 'Multiple Choice' },
    { id: 'true-false', label: 'True/False' },
    { id: 'short-answer', label: 'Short Answer' },
    { id: 'essay', label: 'Essay' }
  ]

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleQuestionInputChange = (e) => {
    const { name, value } = e.target
    setCurrentQuestion(prev => ({ ...prev, [name]: value }))
  }

  const handleOptionChange = (index, value) => {
    const newOptions = [...currentQuestion.options]
    newOptions[index] = value
    setCurrentQuestion(prev => ({ ...prev, options: newOptions }))
  }

  const addQuestion = () => {
    if (!currentQuestion.text.trim()) {
      alert('Please enter question text')
      return
    }

    if (currentQuestion.type === 'multiple-choice') {
      const emptyOptions = currentQuestion.options.filter(opt => !opt.trim())
      if (emptyOptions.length > 0) {
        alert('Please fill all options for multiple choice question')
        return
      }
    }

    const newQuestion = {
      id: Date.now(),
      ...currentQuestion,
      options: [...currentQuestion.options]
    }

    setFormData(prev => ({
      ...prev,
      questions: [...prev.questions, newQuestion]
    }))

    setCurrentQuestion({
      text: '',
      type: 'multiple-choice',
      options: ['', '', '', ''],
      correctAnswer: 0,
      points: 1
    })
  }

  const removeQuestion = (id) => {
    setFormData(prev => ({
      ...prev,
      questions: prev.questions.filter(q => q.id !== id)
    }))
  }

  const editQuestion = (question) => {
    setCurrentQuestion(question)
    removeQuestion(question.id)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (formData.questions.length === 0) {
      alert('Please add at least one question')
      return
    }
    onSubmit(formData)
  }

  const totalPoints = formData.questions.reduce((sum, q) => sum + parseInt(q.points), 0)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="card p-6"
    >
      <h3 className="text-lg font-semibold mb-6">
        {initialData ? 'Edit Quiz' : 'Create New Quiz'}
      </h3>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium mb-2">
              Quiz Title *
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              className="input-field"
              placeholder="e.g., Mathematics Quiz - Algebra Basics"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Subject *
            </label>
            <select
              name="subject"
              value={formData.subject}
              onChange={handleInputChange}
              className="input-field"
              required
            >
              <option value="">Select Subject</option>
              {subjects.map(subject => (
                <option key={subject} value={subject}>{subject}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Grade Level *
            </label>
            <select
              name="grade"
              value={formData.grade}
              onChange={handleInputChange}
              className="input-field"
              required
            >
              <option value="">Select Grade</option>
              {grades.map(grade => (
                <option key={grade} value={grade}>Grade {grade}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Section *
            </label>
            <select
              name="section"
              value={formData.section}
              onChange={handleInputChange}
              className="input-field"
              required
            >
              <option value="">Select Section</option>
              {sections.map(section => (
                <option key={section} value={section}>Section {section}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">
            Description
          </label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleInputChange}
            rows="2"
            className="input-field"
            placeholder="Provide a brief description of the quiz..."
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium mb-2">
              Duration (minutes) *
            </label>
            <div className="relative">
              <Clock className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
              <input
                type="number"
                name="duration"
                value={formData.duration}
                onChange={handleInputChange}
                className="input-field pl-10"
                min="5"
                max="180"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Passing Score (%)
            </label>
            <input
              type="number"
              name="passingScore"
              value={formData.passingScore}
              onChange={handleInputChange}
              className="input-field"
              min="0"
              max="100"
            />
          </div>

          <div className="flex items-end">
            <div className="w-full">
              <label className="block text-sm font-medium mb-2">
                Total Questions: {formData.questions.length}
              </label>
              <div className="flex items-center gap-2">
                <Hash className="h-5 w-5 text-gray-400" />
                <span className="font-medium">Total Points: {totalPoints}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t dark:border-gray-800 pt-6">
          <h4 className="text-lg font-semibold mb-4">Add Questions</h4>

          <div className="space-y-4 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Question Type
                </label>
                <select
                  name="type"
                  value={currentQuestion.type}
                  onChange={handleQuestionInputChange}
                  className="input-field"
                >
                  {questionTypes.map(type => (
                    <option key={type.id} value={type.id}>
                      {type.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Points
                </label>
                <input
                  type="number"
                  name="points"
                  value={currentQuestion.points}
                  onChange={handleQuestionInputChange}
                  className="input-field"
                  min="1"
                  max="100"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Question Text *
              </label>
              <textarea
                name="text"
                value={currentQuestion.text}
                onChange={handleQuestionInputChange}
                rows="2"
                className="input-field"
                placeholder="Enter your question here..."
              />
            </div>

            {currentQuestion.type === 'multiple-choice' && (
              <div>
                <label className="block text-sm font-medium mb-2">
                  Options *
                </label>
                <div className="space-y-2">
                  {currentQuestion.options.map((option, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="correctAnswer"
                        checked={currentQuestion.correctAnswer === index}
                        onChange={() => setCurrentQuestion(prev => ({ ...prev, correctAnswer: index }))}
                        className="h-4 w-4"
                      />
                      <input
                        type="text"
                        value={option}
                        onChange={(e) => handleOptionChange(index, e.target.value)}
                        className="input-field"
                        placeholder={`Option ${index + 1}`}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {currentQuestion.type === 'true-false' && (
              <div>
                <label className="block text-sm font-medium mb-2">
                  Correct Answer
                </label>
                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setCurrentQuestion(prev => ({ ...prev, correctAnswer: 0 }))}
                    className={`px-4 py-2 rounded-lg border ${
                      currentQuestion.correctAnswer === 0
                        ? 'border-green-500 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400'
                        : 'border-gray-200 dark:border-gray-800'
                    }`}
                  >
                    True
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrentQuestion(prev => ({ ...prev, correctAnswer: 1 }))}
                    className={`px-4 py-2 rounded-lg border ${
                      currentQuestion.correctAnswer === 1
                        ? 'border-red-500 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400'
                        : 'border-gray-200 dark:border-gray-800'
                    }`}
                  >
                    False
                  </button>
                </div>
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="button"
                onClick={addQuestion}
                className="btn-primary flex items-center gap-2"
              >
                <Plus className="h-4 w-4" />
                Add Question
              </button>
            </div>
          </div>

          {formData.questions.length > 0 && (
            <div className="border-t dark:border-gray-800 pt-6">
              <h5 className="font-semibold mb-4">Added Questions ({formData.questions.length})</h5>
              <div className="space-y-3">
                {formData.questions.map((question, index) => (
                  <div
                    key={question.id}
                    className="flex items-center justify-between p-3 rounded-lg border"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                        <span className="text-sm font-medium text-blue-600 dark:text-blue-400">
                          {index + 1}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium">{question.text.substring(0, 50)}...</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {question.type} • {question.points} points
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => editQuestion(question)}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
                      >
                        <Edit2 className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => removeQuestion(question.id)}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
                      >
                        <Trash2 className="h-4 w-4 text-red-600" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center justify-end gap-4 pt-6 border-t dark:border-gray-800">
          <button
            type="button"
            onClick={onCancel}
            className="btn-secondary"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="btn-primary flex items-center gap-2"
          >
            <Plus className="h-4 w-4" />
            {initialData ? 'Update Quiz' : 'Create Quiz'}
          </button>
        </div>
      </form>
    </motion.div>
  )
}

export default QuizForm