export const formatDate = (dateString, format = 'medium') => {
    if (!dateString) return ''
    
    const date = new Date(dateString)
    const options = {
      short: { year: 'numeric', month: 'short', day: 'numeric' },
      medium: { year: 'numeric', month: 'long', day: 'numeric' },
      long: { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' },
      time: { hour: '2-digit', minute: '2-digit' },
      datetime: { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }
    }
  
    return date.toLocaleDateString('en-US', options[format] || options.medium)
  }
  
  export const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes'
    
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }
  
  export const truncateText = (text, maxLength = 100) => {
    if (text.length <= maxLength) return text
    return text.substring(0, maxLength) + '...'
  }
  
  export const calculateGrade = (score, maxScore = 100) => {
    const percentage = (score / maxScore) * 100
    
    if (percentage >= 90) return 'A'
    if (percentage >= 80) return 'B'
    if (percentage >= 70) return 'C'
    if (percentage >= 60) return 'D'
    return 'F'
  }
  
  export const getGradeColor = (grade) => {
    const colors = {
      'A': 'text-green-600 dark:text-green-400',
      'B': 'text-blue-600 dark:text-blue-400',
      'C': 'text-yellow-600 dark:text-yellow-400',
      'D': 'text-orange-600 dark:text-orange-400',
      'F': 'text-red-600 dark:text-red-400'
    }
    return colors[grade] || 'text-gray-600 dark:text-gray-400'
  }
  
  export const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return re.test(email)
  }
  
  export const validatePassword = (password) => {
    return password.length >= 8
  }
  
  export const validatePhone = (phone) => {
    const re = /^\+?[\d\s\-\(\)]+$/
    return re.test(phone)
  }
  
  export const debounce = (func, wait) => {
    let timeout
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout)
        func(...args)
      }
      clearTimeout(timeout)
      timeout = setTimeout(later, wait)
    }
  }
  
  export const formatCurrency = (amount, currency = 'ETB') => {
    return new Intl.NumberFormat('en-ET', {
      style: 'currency',
      currency: currency
    }).format(amount)
  }
  
  export const generateColorFromString = (str) => {
    let hash = 0
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash)
    }
    
    const colors = [
      '#3B82F6', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444',
      '#EC4899', '#14B8A6', '#6366F1', '#F97316', '#84CC16'
    ]
    
    return colors[Math.abs(hash) % colors.length]
  }
export default helpers.js